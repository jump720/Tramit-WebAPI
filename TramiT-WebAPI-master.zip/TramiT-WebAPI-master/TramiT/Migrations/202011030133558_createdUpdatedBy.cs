﻿namespace TramiT.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class createdUpdatedBy : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.MultasDetalle", "Created_by", c => c.String());
            AddColumn("dbo.MultasDetalle", "Updated_by", c => c.String());
            AddColumn("dbo.ListadosDetalle", "Created_by", c => c.String());
            AddColumn("dbo.ListadosDetalle", "Updated_by", c => c.String());
            AddColumn("dbo.Tramites", "Created_by", c => c.String());
            AddColumn("dbo.Tramites", "Updated_by", c => c.String());
            AddColumn("dbo.Ingresos", "Created_by", c => c.String());
            AddColumn("dbo.Ingresos", "Updated_by", c => c.String());
        }
        
        public override void Down()
        {
            DropColumn("dbo.Ingresos", "Updated_by");
            DropColumn("dbo.Ingresos", "Created_by");
            DropColumn("dbo.Tramites", "Updated_by");
            DropColumn("dbo.Tramites", "Created_by");
            DropColumn("dbo.ListadosDetalle", "Updated_by");
            DropColumn("dbo.ListadosDetalle", "Created_by");
            DropColumn("dbo.MultasDetalle", "Updated_by");
            DropColumn("dbo.MultasDetalle", "Created_by");
        }
    }
}
