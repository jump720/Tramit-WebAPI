﻿namespace TramiT.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class CierreDetalleDeleteTipoRegistro : DbMigration
    {
        public override void Up()
        {
            DropColumn("dbo.CierreDetalle", "TipoRegistro");
            DropColumn("dbo.CierreDetalle", "RegistroId");
        }
        
        public override void Down()
        {
            AddColumn("dbo.CierreDetalle", "RegistroId", c => c.String(nullable: false));
            AddColumn("dbo.CierreDetalle", "TipoRegistro", c => c.Int(nullable: false));
        }
    }
}
