﻿namespace TramiT.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class MovimientosPendientesCierreAlter : DbMigration
    {
        public override void Up()
        {
            //RenameTable(name: "dbo.GastosPendientesCierre", newName: "VW_GastosPendientesCierre");
            //RenameTable(name: "dbo.IngresosPendientesCierre", newName: "VW_IngresosPendientesCierre");
        }
        
        public override void Down()
        {
            //RenameTable(name: "dbo.VW_IngresosPendientesCierre", newName: "IngresosPendientesCierre");
            //RenameTable(name: "dbo.VW_GastosPendientesCierre", newName: "GastosPendientesCierre");
        }
    }
}
