﻿namespace TramiT.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class _09092020_Tramites_Productos_Gastos_AlterTable : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Productos", "TipoProducto", c => c.Int());
            AddColumn("dbo.Gastos", "TipoGasto", c => c.Int());
            DropColumn("dbo.Tramites", "TipoComparendo");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Tramites", "TipoComparendo", c => c.Int(nullable: false));
            DropColumn("dbo.Gastos", "TipoGasto");
            DropColumn("dbo.Productos", "TipoProducto");
        }
    }
}
