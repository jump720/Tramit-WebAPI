﻿namespace TramiT.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Cierre_Delete_referencia : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.CierreDetalle", "MovimientoId", c => c.String(nullable: false, maxLength: 10));
            DropColumn("dbo.CierreDetalle", "Referencia");
        }
        
        public override void Down()
        {
            AddColumn("dbo.CierreDetalle", "Referencia", c => c.String(maxLength: 20));
            AlterColumn("dbo.CierreDetalle", "MovimientoId", c => c.String(nullable: false));
        }
    }
}
