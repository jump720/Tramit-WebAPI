﻿namespace TramiT.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Tramitadores : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Tramitadores",
                c => new
                    {
                        Codigo = c.String(nullable: false, maxLength: 20),
                        Nombre = c.String(nullable: false, maxLength: 100),
                        Porcentaje = c.Double(),
                        Created_at = c.DateTime(nullable: false),
                        Updated_at = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.Codigo);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.Tramitadores");
        }
    }
}
