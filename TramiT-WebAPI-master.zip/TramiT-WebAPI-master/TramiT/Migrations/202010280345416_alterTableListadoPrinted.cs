﻿namespace TramiT.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class alterTableListadoPrinted : DbMigration
    {
        public override void Up()
        {
            DropColumn("dbo.Listados", "CantidadImpresiones");
            DropColumn("dbo.Listados", "Printed_at");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Listados", "Printed_at", c => c.DateTime(nullable: false));
            AddColumn("dbo.Listados", "CantidadImpresiones", c => c.Int());
        }
    }
}
