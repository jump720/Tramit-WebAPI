﻿namespace TramiT.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class MultaDetalleAlter : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.MultasDetalle", "EnProcesoPago", c => c.Boolean(nullable: false));
            DropColumn("dbo.Multas", "Estado");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Multas", "Estado", c => c.Int(nullable: false));
            DropColumn("dbo.MultasDetalle", "EnProcesoPago");
        }
    }
}
