﻿namespace TramiT.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class CelularCorreoClientes : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Clientes", "Celular", c => c.String(maxLength: 30));
            AddColumn("dbo.Clientes", "Correo", c => c.String(maxLength: 200));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Clientes", "Correo");
            DropColumn("dbo.Clientes", "Celular");
        }
    }
}
