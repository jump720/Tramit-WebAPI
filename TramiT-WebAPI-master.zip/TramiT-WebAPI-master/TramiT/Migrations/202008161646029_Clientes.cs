﻿namespace TramiT.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Clientes : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Asamblea",
                c => new
                    {
                        Identificacion = c.String(nullable: false, maxLength: 20),
                        Nombres = c.String(nullable: false, maxLength: 50),
                        Apellidos = c.String(nullable: false, maxLength: 50),
                        Created_at = c.DateTime(nullable: false),
                        Updated_at = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.Identificacion);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.Asamblea");
        }
    }
}
