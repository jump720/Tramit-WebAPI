﻿namespace TramiT.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Productos_Gastos_AlterTable_required : DbMigration
    {
        public override void Up()
        {
            Sql("UPDATE dbo.Productos SET TipoProducto = 1 WHERE TipoProducto IS NULL");
            Sql("UPDATE dbo.Gastos SET TipoGasto = 1 WHERE TipoGasto IS NULL");
            AlterColumn("dbo.Productos", "TipoProducto", c => c.Int(nullable: false, defaultValue: 1));
            AlterColumn("dbo.Gastos", "TipoGasto", c => c.Int(nullable: false, defaultValue: 1));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Gastos", "TipoGasto", c => c.Int());
            AlterColumn("dbo.Productos", "TipoProducto", c => c.Int());
        }
    }
}
