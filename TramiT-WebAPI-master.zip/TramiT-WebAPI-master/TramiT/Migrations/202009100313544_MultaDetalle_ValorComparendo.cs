﻿namespace TramiT.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class MultaDetalle_ValorComparendo : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.MultasDetalle", "ValorComparendo", c => c.Double(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.MultasDetalle", "ValorComparendo");
        }
    }
}
