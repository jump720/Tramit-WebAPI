﻿namespace TramiT.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class printedListado : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Listados", "CantidadImpresiones", c => c.Int());
            AddColumn("dbo.Listados", "Printed_at", c => c.DateTime(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Listados", "Printed_at");
            DropColumn("dbo.Listados", "CantidadImpresiones");
        }
    }
}
