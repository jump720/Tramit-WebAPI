﻿namespace TramiT.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class CierreDetalleVW : DbMigration
    {
        public override void Up()
        {
            //CreateTable(
            //    "dbo.VW_CierreDetalle",
            //    c => new
            //        {
            //            Id = c.Int(nullable: false, identity: true),
            //            CierreId = c.Long(nullable: false),
            //            TipoMovimiento = c.Int(nullable: false),
            //            MovimientoId = c.String(),
            //            Created_at = c.DateTime(nullable: false),
            //            Updated_at = c.DateTime(nullable: false),
            //            Created_by = c.String(),
            //            Updated_by = c.String(),
            //            MovimientoDesc = c.String(),
            //            MovimientoValor = c.Double(nullable: false),
            //            MovimientoCreated_at = c.DateTime(nullable: false),
            //            MovimientoEstado = c.Int(nullable: false),
            //            MovimientoTipo = c.Int(nullable: false),
            //            ClienteId = c.String(),
            //            ClienteNombre = c.String(),
            //            TramitadorId = c.String(),
            //            TramitadorNombre = c.String(),
            //            EstadoMovimiento = c.String(),
            //            Producto = c.String(),
            //        })
            //    .PrimaryKey(t => t.Id);
            
        }
        
        public override void Down()
        {
            //DropTable("dbo.VW_CierreDetalle");
        }
    }
}
