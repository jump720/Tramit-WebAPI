﻿namespace TramiT.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class TramitesValorComparendo : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Tramites", "ValorComparendo", c => c.Double(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Tramites", "ValorComparendo");
        }
    }
}
