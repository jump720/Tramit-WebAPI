﻿namespace TramiT.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ComisionTramitador : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Tramites", "ComisionTramitador", c => c.Double());
        }
        
        public override void Down()
        {
            DropColumn("dbo.Tramites", "ComisionTramitador");
        }
    }
}
