﻿namespace TramiT.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class TipoComparendos_Multas_MultasDetalle : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Multas",
                c => new
                    {
                        Id = c.Long(nullable: false, identity: true),
                        ClienteId = c.String(nullable: false, maxLength: 20),
                        ProductoId = c.Int(nullable: false),
                        TramitadorId = c.String(nullable: false, maxLength: 20),
                        Estado = c.Int(nullable: false),
                        Clasificacion = c.Int(nullable: false),
                        Created_at = c.DateTime(nullable: false),
                        Updated_at = c.DateTime(nullable: false),
                        Nota = c.String(maxLength: 500),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Productos", t => t.ProductoId)
                .ForeignKey("dbo.Tramitadores", t => t.TramitadorId)
                .ForeignKey("dbo.Clientes", t => t.ClienteId)
                .Index(t => t.ClienteId)
                .Index(t => t.ProductoId)
                .Index(t => t.TramitadorId);
            
            CreateTable(
                "dbo.MultasDetalle",
                c => new
                    {
                        MultaId = c.Long(nullable: false),
                        ItemId = c.Int(nullable: false),
                        TipoComparendoId = c.Int(nullable: false),
                        Comparendo = c.String(maxLength: 20),
                        Resolucion = c.String(maxLength: 20),
                        Porcentaje = c.Double(nullable: false),
                        Valor = c.Double(nullable: false),
                        Estado = c.Int(nullable: false),
                        Created_at = c.DateTime(nullable: false),
                        Updated_at = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => new { t.MultaId, t.ItemId })
                .ForeignKey("dbo.TipoComparendos", t => t.TipoComparendoId)
                .ForeignKey("dbo.Multas", t => t.MultaId)
                .Index(t => t.MultaId)
                .Index(t => t.TipoComparendoId);
            
            CreateTable(
                "dbo.TipoComparendos",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Nombre = c.String(nullable: false, maxLength: 50),
                    })
                .PrimaryKey(t => t.Id);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Multas", "ClienteId", "dbo.Clientes");
            DropForeignKey("dbo.Multas", "TramitadorId", "dbo.Tramitadores");
            DropForeignKey("dbo.Multas", "ProductoId", "dbo.Productos");
            DropForeignKey("dbo.MultasDetalle", "MultaId", "dbo.Multas");
            DropForeignKey("dbo.MultasDetalle", "TipoComparendoId", "dbo.TipoComparendos");
            DropIndex("dbo.MultasDetalle", new[] { "TipoComparendoId" });
            DropIndex("dbo.MultasDetalle", new[] { "MultaId" });
            DropIndex("dbo.Multas", new[] { "TramitadorId" });
            DropIndex("dbo.Multas", new[] { "ProductoId" });
            DropIndex("dbo.Multas", new[] { "ClienteId" });
            DropTable("dbo.TipoComparendos");
            DropTable("dbo.MultasDetalle");
            DropTable("dbo.Multas");
        }
    }
}
