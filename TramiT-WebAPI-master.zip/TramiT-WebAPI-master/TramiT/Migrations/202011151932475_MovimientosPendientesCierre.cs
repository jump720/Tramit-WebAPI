﻿namespace TramiT.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class MovimientosPendientesCierre : DbMigration
    {
        public override void Up()
        {
            //CreateTable(
            //    "dbo.GastosPendientesCierre",
            //    c => new
            //        {
            //            Id = c.Long(nullable: false, identity: true),
            //            Descripcion = c.String(),
            //            Referencia = c.String(),
            //            TipoGasto = c.Int(nullable: false),
            //            Estado = c.Int(nullable: false),
            //            Nota = c.String(),
            //            Valor = c.Double(nullable: false),
            //            Created_at = c.DateTime(nullable: false),
            //            Updated_at = c.DateTime(nullable: false),
            //            Created_by = c.String(),
            //            Updated_by = c.String(),
            //            ClienteId = c.String(),
            //            ClienteNombre = c.String(),
            //            TramitadorId = c.String(),
            //            TramitadorNombre = c.String(),
            //            EstadoMovimiento = c.String(),
            //            Producto = c.String(),
            //        })
            //    .PrimaryKey(t => t.Id);
            
            //CreateTable(
            //    "dbo.IngresosPendientesCierre",
            //    c => new
            //        {
            //            Id = c.Long(nullable: false, identity: true),
            //            Descripcion = c.String(),
            //            Referencia = c.String(),
            //            TipoIngreso = c.Int(nullable: false),
            //            Estado = c.Int(nullable: false),
            //            Nota = c.String(),
            //            Valor = c.Double(nullable: false),
            //            Created_at = c.DateTime(nullable: false),
            //            Updated_at = c.DateTime(nullable: false),
            //            Created_by = c.String(),
            //            Updated_by = c.String(),
            //            ClienteId = c.String(),
            //            ClienteNombre = c.String(),
            //            TramitadorId = c.String(),
            //            TramitadorNombre = c.String(),
            //            EstadoMovimiento = c.String(),
            //            Producto = c.String(),
            //        })
            //    .PrimaryKey(t => t.Id);
            
        }
        
        public override void Down()
        {
            //DropTable("dbo.IngresosPendientesCierre");
            //DropTable("dbo.GastosPendientesCierre");
        }
    }
}
