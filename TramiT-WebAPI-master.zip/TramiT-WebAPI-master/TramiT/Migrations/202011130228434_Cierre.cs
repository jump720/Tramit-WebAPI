﻿namespace TramiT.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Cierre : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Cierre",
                c => new
                    {
                        Id = c.Long(nullable: false, identity: true),
                        Nota = c.String(maxLength: 500),
                        FechaInicio = c.DateTime(nullable: false),
                        FechaFin = c.DateTime(nullable: false),
                        Estado = c.Int(nullable: false),
                        Created_at = c.DateTime(nullable: false),
                        Updated_at = c.DateTime(nullable: false),
                        Created_by = c.String(),
                        Updated_by = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.CierreDetalle",
                c => new
                    {
                        CierreId = c.Long(nullable: false),
                        Id = c.Int(nullable: false),
                        Referencia = c.String(maxLength: 20),
                        TipoRegistro = c.Int(nullable: false),
                        RegistroId = c.String(nullable: false),
                        TipoMovimiento = c.Int(nullable: false),
                        MovimientoId = c.String(nullable: false),
                        Created_at = c.DateTime(nullable: false),
                        Updated_at = c.DateTime(nullable: false),
                        Created_by = c.String(),
                        Updated_by = c.String(),
                    })
                .PrimaryKey(t => new { t.CierreId, t.Id })
                .ForeignKey("dbo.Cierre", t => t.CierreId)
                .Index(t => t.CierreId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.CierreDetalle", "CierreId", "dbo.Cierre");
            DropIndex("dbo.CierreDetalle", new[] { "CierreId" });
            DropTable("dbo.CierreDetalle");
            DropTable("dbo.Cierre");
        }
    }
}
