﻿namespace TramiT.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class EstadoListado : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Listados", "Estado", c => c.Int(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Listados", "Estado");
        }
    }
}
