﻿namespace TramiT.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ListadoDetallePagado : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.ListadosDetalle", "Pagado", c => c.Boolean(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.ListadosDetalle", "Pagado");
        }
    }
}
