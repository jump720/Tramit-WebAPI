﻿namespace TramiT.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ComisionTramitadorMultas : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Multas", "ComisionTramitador", c => c.Double());
        }
        
        public override void Down()
        {
            DropColumn("dbo.Multas", "ComisionTramitador");
        }
    }
}
