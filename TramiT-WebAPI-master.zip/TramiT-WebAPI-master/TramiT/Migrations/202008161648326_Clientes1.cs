﻿namespace TramiT.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Clientes1 : DbMigration
    {
        public override void Up()
        {
            RenameTable(name: "dbo.Asamblea", newName: "Clientes");
        }
        
        public override void Down()
        {
            RenameTable(name: "dbo.Clientes", newName: "Asamblea");
        }
    }
}
