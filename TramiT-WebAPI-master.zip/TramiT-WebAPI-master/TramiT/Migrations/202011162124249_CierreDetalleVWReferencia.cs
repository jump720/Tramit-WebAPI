﻿namespace TramiT.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class CierreDetalleVWReferencia : DbMigration
    {
        public override void Up()
        {
            //AddColumn("dbo.VW_CierreDetalle", "Referencia", c => c.String());
        }
        
        public override void Down()
        {
            //DropColumn("dbo.VW_CierreDetalle", "Referencia");
        }
    }
}
