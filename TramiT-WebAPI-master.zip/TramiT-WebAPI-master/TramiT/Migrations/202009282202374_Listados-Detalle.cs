﻿namespace TramiT.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ListadosDetalle : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.ListadosDetalle",
                c => new
                    {
                        ListadoId = c.Long(nullable: false),
                        Id = c.Int(nullable: false),
                        MultaId = c.Long(nullable: false),
                        MultaItemId = c.Int(nullable: false),
                        Nota = c.String(maxLength: 500),
                        Created_at = c.DateTime(nullable: false),
                        Updated_at = c.DateTime(nullable: false),
                        Estado = c.Int(nullable: false),
                    })
                .PrimaryKey(t => new { t.ListadoId, t.Id })
                .ForeignKey("dbo.Listados", t => t.ListadoId)
                .ForeignKey("dbo.MultasDetalle", t => new { t.MultaId, t.MultaItemId })
                .Index(t => new { t.ListadoId, t.MultaId, t.MultaItemId }, unique: true);
            
            CreateTable(
                "dbo.Listados",
                c => new
                    {
                        Id = c.Long(nullable: false, identity: true),
                        Titulo = c.String(nullable: false, maxLength: 100),
                        Created_at = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.Id);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.ListadosDetalle", new[] { "MultaId", "MultaItemId" }, "dbo.MultasDetalle");
            DropForeignKey("dbo.ListadosDetalle", "ListadoId", "dbo.Listados");
            DropIndex("dbo.ListadosDetalle", new[] { "ListadoId", "MultaId", "MultaItemId" });
            DropTable("dbo.Listados");
            DropTable("dbo.ListadosDetalle");
        }
    }
}
