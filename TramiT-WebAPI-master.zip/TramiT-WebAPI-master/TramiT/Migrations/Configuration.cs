﻿namespace TramiT.Migrations
{
    using Microsoft.AspNet.Identity;
    using Microsoft.AspNet.Identity.EntityFramework;
    using Microsoft.AspNet.Identity.Owin;
    using System.Data.Entity.Migrations;
    using System.Web;
    using TramiT.Models;

    internal sealed class Configuration : DbMigrationsConfiguration<TramiT.Models.TramiTDBContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        
  

        protected override void Seed(TramiT.Models.TramiTDBContext context)
        {
            //  This method will be called after migrating to the latest version.

            //  You can use the DbSet<T>.AddOrUpdate() helper extension method
            //  to avoid creating duplicate seed data.

            context.Tramitadores.AddOrUpdate(e => e.Codigo,
                new Models.Tramitadores() { Codigo = "1", Nombre = "Doris", Porcentaje = 0 },
                new Models.Tramitadores() { Codigo = "2", Nombre = "Oficina", Porcentaje = 0 }
                );




            UserStore<TramiT.Models.IdentityModel> userStore = new UserStore<TramiT.Models.IdentityModel>(context);
            var userManager = new UserManager<TramiT.Models.IdentityModel>(userStore);

            ////var roleManager = HttpContext.Current.GetOwinContext().Get<ApplicationRoleManager>();
            const string name = "carlos16931@hotmail.com";
            const string password = "Programador2";

            ////const string roleName = "Admin";

            ////Create Role Admin if it does not exist
            ////var role = roleManager.FindByName(roleName);
            ////if (role == null)
            ////{
            ////    role = new IdentityRole(roleName);
            ////    var roleresult = roleManager.Create(role);
            ////}

            var user = userManager.FindByName(name);
            if (user == null)
            {
                user = new TramiT.Models.IdentityModel()
                {
                    UserName = name,
                    Email = name,
                    FirstName = "Admin",
                    LastName = "Admin"
                };
                var result = userManager.Create(user, password);
                result = userManager.SetLockoutEnabled(user.Id, false);
            }

            // Add user admin to Role Admin if not already added
            //var rolesForUser = userManager.GetRoles(user.Id);
            //if (!rolesForUser.Contains(role.Name))
            //{
            //    var result = userManager.AddToRole(user.Id, role.Name);
            //}

        }
    }
}
