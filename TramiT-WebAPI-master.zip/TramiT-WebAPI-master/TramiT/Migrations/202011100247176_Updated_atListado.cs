﻿namespace TramiT.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Updated_atListado : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Listados", "Updated_at", c => c.DateTime(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Listados", "Updated_at");
        }
    }
}
