﻿namespace TramiT.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Gastos : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Gastos",
                c => new
                    {
                        Id = c.Long(nullable: false, identity: true),
                        Descripcion = c.String(nullable: false, maxLength: 100),
                        Referencia = c.String(nullable: false, maxLength: 20),
                        Estado = c.Int(nullable: false),
                        Nota = c.String(maxLength: 500),
                        Valor = c.Double(nullable: false),
                        Created_at = c.DateTime(nullable: false),
                        Updated_at = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.Id);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.Gastos");
        }
    }
}
