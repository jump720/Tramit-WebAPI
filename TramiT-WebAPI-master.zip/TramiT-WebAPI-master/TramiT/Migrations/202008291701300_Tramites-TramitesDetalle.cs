﻿namespace TramiT.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class TramitesTramitesDetalle : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Tramites",
                c => new
                    {
                        Id = c.Long(nullable: false, identity: true),
                        ClienteId = c.String(nullable: false, maxLength: 20),
                        Estado = c.Int(nullable: false),
                        ProductoId = c.Int(nullable: false),
                        Comparendo = c.String(maxLength: 20),
                        TipoComparendo = c.Int(nullable: false),
                        Placa = c.String(maxLength: 10),
                        TramitadorId = c.String(nullable: false, maxLength: 20),
                        Nota = c.String(maxLength: 500),
                        Created_at = c.DateTime(nullable: false),
                        Updated_at = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Productos", t => t.ProductoId)
                .ForeignKey("dbo.Tramitadores", t => t.TramitadorId)
                .ForeignKey("dbo.Clientes", t => t.ClienteId)
                .Index(t => t.ClienteId)
                .Index(t => t.ProductoId)
                .Index(t => t.TramitadorId);
            
            CreateTable(
                "dbo.TramitesDetalle",
                c => new
                    {
                        TramiteId = c.Long(nullable: false),
                        ItemId = c.Int(nullable: false),
                        Concepto = c.String(nullable: false, maxLength: 50),
                        Porcentaje = c.Double(nullable: false),
                        Valor = c.Double(nullable: false),
                    })
                .PrimaryKey(t => new { t.TramiteId, t.ItemId })
                .ForeignKey("dbo.Tramites", t => t.TramiteId)
                .Index(t => t.TramiteId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Tramites", "ClienteId", "dbo.Clientes");
            DropForeignKey("dbo.TramitesDetalle", "TramiteId", "dbo.Tramites");
            DropForeignKey("dbo.Tramites", "TramitadorId", "dbo.Tramitadores");
            DropForeignKey("dbo.Tramites", "ProductoId", "dbo.Productos");
            DropIndex("dbo.TramitesDetalle", new[] { "TramiteId" });
            DropIndex("dbo.Tramites", new[] { "TramitadorId" });
            DropIndex("dbo.Tramites", new[] { "ProductoId" });
            DropIndex("dbo.Tramites", new[] { "ClienteId" });
            DropTable("dbo.TramitesDetalle");
            DropTable("dbo.Tramites");
        }
    }
}
