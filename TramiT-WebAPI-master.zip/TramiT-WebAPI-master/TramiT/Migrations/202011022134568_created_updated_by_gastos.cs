﻿namespace TramiT.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class created_updated_by_gastos : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Gastos", "Created_by", c => c.String());
            AddColumn("dbo.Gastos", "Updated_by", c => c.String());
        }
        
        public override void Down()
        {
            DropColumn("dbo.Gastos", "Updated_by");
            DropColumn("dbo.Gastos", "Created_by");
        }
    }
}
