﻿using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.Owin;
using System;
using System.Collections.Concurrent;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using TramiT.Models;
//https://docs.microsoft.com/en-us/aspnet/core/security/authentication/identity-custom-storage-providers?view=aspnetcore-3.1
namespace TramiT
{
    public class ApplicationUserManager : UserManager<IdentityModel>
    {
        public ApplicationUserManager(IUserStore<IdentityModel> store, IIdentityMessageService emailService)
        : base(store)
        {
            this.EmailService = emailService;
        }


        public static ApplicationUserManager Create(IdentityFactoryOptions<ApplicationUserManager> options, IOwinContext context)
        {
            var manager = new ApplicationUserManager(new UserStore<IdentityModel>(context.Get<TramiTDBContext>()), new EmailService());
            // Configure validation logic for usernames
            manager.UserValidator = new UserValidator<IdentityModel>(manager)
            {
                AllowOnlyAlphanumericUserNames = false,
                RequireUniqueEmail = true
            };
            // Configure validation logic for passwords
            manager.PasswordValidator = new PasswordValidator
            {
                RequiredLength = 6,
                RequireNonLetterOrDigit = false,
                RequireDigit = true,
                RequireLowercase = true,
                RequireUppercase = true,
            };
            var dataProtectionProvider = options.DataProtectionProvider;
            if (dataProtectionProvider != null)
            {
                manager.UserTokenProvider = new DataProtectorTokenProvider<IdentityModel>(dataProtectionProvider.Create("ASP.NET Identity"));
            }


            //Seed Database

            //const string name = "carlos16931@hotmail.com";
            //const string password = "Programador2";

            //var roleManager = HttpContext.Current.GetOwinContext().Get<ApplicationRoleManager>();

            //var user = manager.FindByName(name);
            //if (user == null)
            //{
            //    user = new IdentityModel()
            //    {
            //        UserName = name,
            //        Email = name,
            //        FirstName = "Admin",
            //        LastName = "Admin"
            //    };
            //    var result = manager.Create(user, password);
            //    result = manager.SetLockoutEnabled(user.Id, false);
            //}

            return manager;
        }
    }

    public class ApplicationRoleManager : RoleManager<IdentityRole>
    {
        public ApplicationRoleManager(IRoleStore<IdentityRole, string> store) : base(store)
        {
        }

        public static ApplicationRoleManager Create(IdentityFactoryOptions<ApplicationRoleManager> options, IOwinContext context)
        {
            return new ApplicationRoleManager(new RoleStore<IdentityRole>(context.Get<TramiTDBContext>()));
        }
    }


    public class EmailService : IIdentityMessageService
    {
        readonly ConcurrentQueue<SmtpClient> _clients = new ConcurrentQueue<SmtpClient>();

        public async Task SendAsync(IdentityMessage message)
        {
            var client = GetOrCreateSmtpClient();
            try
            {
                MailMessage mailMessage = new MailMessage();

                mailMessage.To.Add(new MailAddress(message.Destination));
                mailMessage.Subject = message.Subject;
                mailMessage.Body = message.Body;

                mailMessage.BodyEncoding = Encoding.UTF8;
                mailMessage.SubjectEncoding = Encoding.UTF8;
                mailMessage.IsBodyHtml = true;

                // there can only ever be one-1 concurrent call to SendMailAsync
                await client.SendMailAsync(mailMessage);
            }
            finally
            {
                _clients.Enqueue(client);
            }
        }

        private SmtpClient GetOrCreateSmtpClient()
        {
            SmtpClient client = null;
            if (_clients.TryDequeue(out client))
            {
                return client;
            }

            client = new SmtpClient();
            return client;
        }
    }
    //public class ApplicationUserStore : UserStore<IdentityModel, ApplicationRole, string, ApplicationUserLogin, ApplicationUserRole, ApplicationUserClaim>
    //{
    //    public ApplicationUserStore(TramiTDBContext context)
    //        : base(context)
    //    {
    //    }

    //    public override async Task CreateAsync(IdentityModel user)
    //    {
    //        await base.CreateAsync(user);

    //    }
    //}

}