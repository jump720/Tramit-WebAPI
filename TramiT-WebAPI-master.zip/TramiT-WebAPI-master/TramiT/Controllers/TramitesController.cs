﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http;
using TramiT.Classes;
using TramiT.Models;
using TramiT.Models.ViewModel;

namespace TramiT.Controllers
{
    public class TramitesController : ApiBaseController
    {
        private TramiTDBContext db = new TramiTDBContext();

        public async Task<IHttpActionResult> Get(int page = 0, int length = 20, string search = "", int? estado = 0, string cliente_id = "", string fecha = "")
        {
            var dataQuery = db.Tramites.AsQueryable();

            if (!string.IsNullOrWhiteSpace(cliente_id))
            {
                string value = cliente_id.ToLower().Trim();
                dataQuery = dataQuery.Where(e => e.Clientes.Identificacion.ToLower() == value);
            }

            if (!string.IsNullOrWhiteSpace(search))
            {
                string value = search.ToLower().Trim();
                dataQuery = dataQuery.Where(e => 
                    e.Id.ToString().Contains(value) ||
                    e.Clientes.Identificacion.ToLower().ToString().Contains(value) ||
                    e.Productos.Nombre.ToLower().ToString().Contains(value) ||
                    e.Comparendo.ToLower().Contains(value) ||
                    e.Placa.ToLower().Contains(value));
            }

            if (!string.IsNullOrWhiteSpace(fecha))
            {
                var value = Convert.ToDateTime(fecha.ToLower().Trim()).Date;
                dataQuery = dataQuery.Where(e => DbFunctions.TruncateTime(e.Created_at) == value);
            }

            if (estado != 0 && estado != null)
            {
                dataQuery = dataQuery.Where(e => e.Estado == (EstadoTramite)estado);
            }

            int count = await dataQuery.CountAsync();

            var data = await dataQuery
                .Include(e=> e.Clientes)
                .Include(e=> e.Tramitadores)
                .Include(e=> e.Productos)
                .Include(e=> e.TramitesDetalle)
                .OrderBy(e => e.Estado)
                .ThenByDescending(e => e.Created_at)
                .ThenBy(e => e.Clientes.Identificacion)
                .ThenBy(e => e.Productos.Nombre)
                .Skip(page * length).Take(length).ToListAsync();

            return Ok(new
            {
                count,
                data = data.Select(e => new
                {
                    e.Id,
                    ClienteId = e.Clientes.Identificacion,
                    ClienteNombres = e.Clientes.Nombres,
                    ClienteApellidos = e.Clientes.Apellidos,
                    EstadoTexto = e.Estado.ToString(),
                    e.Estado,
                    TramitadorCodigo = e.Tramitadores.Codigo,
                    TramitadorNombre = e.Tramitadores.Nombre,
                    ProductoId = e.Productos.Nombre,
                    ProductoNombre = e.Productos.Nombre,
                    e.Comparendo,
                    e.Placa,
                    Created_at = e.Created_at.ToString("d"),
                    Total = e.TramitesDetalle.Sum(d => d.Valor)
                })
            });
        }

        [HttpGet]
        [Route("api/Tramites/GetByTramitador/{tramitador_id}")]
        public async Task<IHttpActionResult> GetByTramitador(string tramitador_id, int page = 0, int length = 20, string search = "", int? estado = 0, string fecha = "")
        {
            var dataQuery = db.Tramites.Where(e => e.Tramitadores.Codigo.ToLower() == tramitador_id).AsQueryable();

            
            if (!string.IsNullOrWhiteSpace(search))
            {
                string value = search.ToLower().Trim();
                dataQuery = dataQuery.Where(e =>
                    e.Id.ToString().Contains(value) ||
                    e.Clientes.Identificacion.ToLower().ToString().Contains(value) ||
                    e.Productos.Nombre.ToLower().ToString().Contains(value) ||
                    e.Comparendo.ToLower().Contains(value) ||
                    e.Placa.ToLower().Contains(value));
            }

            if (!string.IsNullOrWhiteSpace(fecha))
            {
                var value = Convert.ToDateTime(fecha.ToLower().Trim()).Date;
                dataQuery = dataQuery.Where(e => DbFunctions.TruncateTime(e.Created_at) == value);
            }

            if (estado != 0 && estado != null)
            {
                dataQuery = dataQuery.Where(e => e.Estado == (EstadoTramite)estado);
            }

            int count = await dataQuery.CountAsync();

            var data = await dataQuery
                .Include(e => e.Clientes)
                .Include(e => e.Tramitadores)
                .Include(e => e.Productos)
                .Include(e => e.TramitesDetalle)
                .OrderBy(e => e.Estado)
                .ThenByDescending(e => e.Created_at)
                .ThenBy(e => e.Clientes.Identificacion)
                .ThenBy(e => e.Productos.Nombre)
                .Skip(page * length).Take(length).ToListAsync();

            return Ok(new
            {
                count,
                data = data.Select(e => new
                {
                    e.Id,
                    ClienteId = e.Clientes.Identificacion,
                    ClienteNombres = e.Clientes.Nombres,
                    ClienteApellidos = e.Clientes.Apellidos,
                    EstadoTexto = e.Estado.ToString(),
                    e.Estado,
                    TramitadorCodigo = e.Tramitadores.Codigo,
                    TramitadorNombre = e.Tramitadores.Nombre,
                    ProductoId = e.Productos.Nombre,
                    ProductoNombre = e.Productos.Nombre,
                    e.Comparendo,
                    e.Placa,
                    Created_at = e.Created_at.ToString("d"),
                    Total = e.TramitesDetalle.Sum(d => d.Valor)
                })
            });
        }

        public async Task<IHttpActionResult> Get(long id)
        {
            var tramite = await db.Tramites
                                    .Include(e => e.Clientes)
                                    .Include(e => e.Tramitadores)
                                    .Include(e => e.Productos)
                                    .Include(e => e.TramitesDetalle)
                                    .Where(e => e.Id == id)
                                    .FirstOrDefaultAsync();

            if (tramite == null)
                return NotFound();


            double totalGastos = await db.Gastos
                                    .Where(e => e.Estado == EstadoGasto.Ejecutado &&
                                                e.TipoGasto == TipoGasto.Tramite && 
                                                e.Referencia == tramite.Id.ToString())
                                    .SumAsync(e => (double?) e.Valor) ?? 0;
            double totalIngresos = await db.Ingresos
                                    .Where(e => e.Estado == EstadoIngreso.Ejecutado &&
                                                e.TipoIngreso == TipoIngreso.Tramite &&
                                                e.Referencia == tramite.Id.ToString())
                                    .SumAsync(e => (double?) e.Valor) ?? 0;
            return Ok(new
            {
                Tramite = tramite,
                Cliente = new
                {
                    tramite.Clientes.Identificacion,
                    tramite.Clientes.Nombres,
                    tramite.Clientes.Apellidos,
                    tramite.Clientes.Celular,
                    tramite.Clientes.Correo,
                    Fullname = tramite.Clientes.Identificacion + " - " + tramite.Clientes.Nombres + " " + tramite.Clientes.Apellidos
                },
                Producto = new
                {
                    tramite.Productos.Id,
                    tramite.Productos.Nombre,
                    TipoValor = tramite.Productos.TipoValor.ToString(),
                    tramite.Productos.Valor,
                    tramite.Productos.Costo,
                    tramite.Productos.Activo
                },
                Tramitador = tramite.Tramitadores,
                Detalle = tramite.TramitesDetalle,
                TotalGastos = totalGastos,
                TotalIngresos = totalIngresos
            });
        }

        public async Task<IHttpActionResult> Post(TramitesViewModel model)
        {
            if (ModelState.IsValid)
            {
                db.Tramites.Add(model.Tramite);
                await db.SaveChangesAsync();

                
                if (model.Detalle.Count > 0)
                {
                    await SaveDetalle(model.Tramite.Id, model.Detalle);
                }


                await AddLog("Create", model.Tramite.Id.ToString(), model);
                return Ok(model.Tramite.Id);
            }

            return BadRequest(ModelState);
        }

        public async Task<IHttpActionResult> Put(TramitesViewModel model)
        {
            if (ModelState.IsValid)
            {
                db.Entry(model.Tramite).State = EntityState.Modified;
                db.Entry(model.Tramite).Property(e => e.Created_at).IsModified = false;
                await db.SaveChangesAsync();

                await AddLog("Edit", model.Tramite.Id.ToString(), model);

                await SaveDetalle(model.Tramite.Id, model.Detalle);
                return Ok(model);
            }

            return BadRequest(ModelState);
        }

        [HttpPost]
        [Route("api/Tramites/Pendiente/{id}")]
        public async Task<IHttpActionResult> Pendiente(long id)
        {
            var tramite = await db.Tramites.Where(e => e.Id == id).FirstOrDefaultAsync();

            if (tramite == null)
                return NotFound();

            tramite.Estado = EstadoTramite.Pendiente;
            db.Entry(tramite).State = EntityState.Modified;
            await db.SaveChangesAsync();

            await AddLog("Pendiente", tramite.Id.ToString(), tramite);
            return Ok(tramite.Id);
        }

        [HttpPost]
        [Route("api/Tramites/Anular/{id}")]
        public async Task<IHttpActionResult> Anular(long id)
        {
            var tramite = await db.Tramites.Where(e => e.Id == id).FirstOrDefaultAsync();

            if (tramite == null)
                return NotFound();           

            if (tramite.Estado == EstadoTramite.Pendiente)
            {
                tramite.Estado = EstadoTramite.Anulado;
                db.Entry(tramite).State = EntityState.Modified;
                db.Entry(tramite).Property(e => e.Created_at).IsModified = false;
                await db.SaveChangesAsync();

                await AddLog("Anular", tramite.Id.ToString(), tramite);
                return Ok(tramite.Id);
            }
            return BadRequest("Tramite no puede ser anulado");
        }

        [HttpPost]
        [Route("api/Tramites/Finalizar/{id}")]
        public async Task<IHttpActionResult> Finalizar(long id)
        {
            var tramite = await db.Tramites.Where(e => e.Id == id).FirstOrDefaultAsync();

            if (tramite == null)
                return NotFound();
            if (tramite.Estado == EstadoTramite.Pendiente)
            {
                tramite.Estado = EstadoTramite.Completado;
                db.Entry(tramite).State = EntityState.Modified;
                db.Entry(tramite).Property(e => e.Created_at).IsModified = false;
                await db.SaveChangesAsync();
            }

            await AddLog("Finalizar", tramite.Id.ToString(), tramite);
            return Ok(tramite.Id);
        }        

        private async Task SaveDetalle(long t, List<TramitesDetalle> detalle)
        {
            //Items que viene de la base de datos
            var currentDetalle = await db.TramitesDetalle.Where(e => e.TramiteId == t).ToListAsync();
            int nro = (currentDetalle.Max(e => (int?)e.ItemId) ?? 0) + 1;

            //Items de ViewModel o que vienen del formulario HTML
            int[] idsItems = detalle.Select(e => e.ItemId).ToArray();

            //Selecciona que estan en la base de datos, pero que se eliminaron desde el HTML
            var itemsToDelete = currentDetalle.Where(e => !idsItems.Contains(e.ItemId)).ToList();

            if (itemsToDelete.Count > 0)
            {
                db.TramitesDetalle.RemoveRange(itemsToDelete);
                await db.SaveChangesAsync();
            }

            foreach (var item in detalle)
            {
                //Si tiene el Item en cero es nuevo registro

                if (item.ItemId == 0)
                {
                    item.TramiteId = t;
                    item.ItemId = nro;

                    db.TramitesDetalle.Add(item);
                    nro++;
                }
                else
                {
                    var editDetalle = currentDetalle
                            .Where(e => e.ItemId == item.ItemId)
                            .FirstOrDefault();
                    editDetalle.Concepto = item.Concepto;
                    editDetalle.Porcentaje = item.Porcentaje;
                    editDetalle.Valor = item.Valor;
                    db.Entry(editDetalle).State = EntityState.Modified;
                }

                await db.SaveChangesAsync();
            }
        }

        [HttpGet]
        [Route("api/Tramites/Estados")]
        public IHttpActionResult Estados()
        {
            var tipoValor = Fn.EnumToIEnumarable<EstadoTramite>().ToList();
            return Ok(tipoValor);
        }
    }
}
