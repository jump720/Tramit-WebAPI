﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using TramiT.Models;

namespace TramiT.Controllers
{
    public class LogsController : ApiBaseController
    {
        private TramiTDBContext db = new TramiTDBContext();

        public async Task<IHttpActionResult> Get(int page = 0, int length = 20, string search = "")
        {
            var dataQuery = db.Logs.AsQueryable();

            if (!string.IsNullOrWhiteSpace(search))
            {
                string value = search.ToLower().Trim();
                dataQuery = dataQuery
                            .Where(e => e.ControllerName.ToLower().ToString().Contains(value) 
                                            || e.ActionName.ToLower().ToString().Contains(value));
            }

            int count = await dataQuery.CountAsync();
            var data = await dataQuery
                .OrderByDescending(e => e.Created_at)
                .ThenBy(e => e.ControllerName)
                .ThenBy(e => e.ActionName)
                .Skip(page * length).Take(length).ToListAsync();

            return Ok(new { count, data });
        }

        public async Task<IHttpActionResult> Get(long id)
        {
            var log = await db.Logs.Where(e => e.Id == id).FirstOrDefaultAsync();

            if (log == null)
                return NotFound();

            return Ok(log);
        }

        [HttpGet]
        [Route("api/Logs/Controller/{ControllerName}")]
        public async Task<IHttpActionResult> Controlador(string ControllerName)
        {
            var data = await db.Logs
                .Where(e => e.ControllerName.ToLower() == ControllerName.ToLower())
                .OrderByDescending(e => e.Created_at)
                .ThenBy(e => e.ControllerName)
                .ThenBy(e => e.ActionName)
                .ToListAsync();

            return Ok(data);
        }
    }
}
