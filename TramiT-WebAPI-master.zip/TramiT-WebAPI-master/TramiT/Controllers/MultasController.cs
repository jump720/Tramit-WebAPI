﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using TramiT.Classes;
using TramiT.Models;
using TramiT.Models.ViewModel;

namespace TramiT.Controllers
{
    public class MultasController : ApiBaseController
    {
        private TramiTDBContext db = new TramiTDBContext();

        public async Task<IHttpActionResult> Get(int page = 0, int length = 20, string search = "", string cliente_id = "", int? clasificacion = 0, string fecha = "")
        {
            var dataQuery = db.Multas.AsQueryable();

            if (!string.IsNullOrWhiteSpace(cliente_id))
            {
                string value = cliente_id.ToLower().Trim();
                dataQuery = dataQuery.Where(e => e.Clientes.Identificacion.ToLower() == value);
            }

            if (!string.IsNullOrWhiteSpace(search))
            {
                string value = search.ToLower().Trim();
                dataQuery = dataQuery
                        .Where(e => 
                            e.Id.ToString().Contains(value) ||
                            e.Clientes.Identificacion.ToLower().ToString().Contains(value) ||
                            e.Productos.Nombre.ToLower().ToString().Contains(value) );
            }

            if (!string.IsNullOrWhiteSpace(fecha))
            {
                var value = Convert.ToDateTime(fecha.ToLower().Trim()).Date;
                dataQuery = dataQuery.Where(e => DbFunctions.TruncateTime(e.Created_at) == value);
            }

            if (clasificacion != 0 && clasificacion != null)
            {                
                dataQuery = dataQuery.Where(e => e.Clasificacion == (Clasificacion)clasificacion);
            }

            int count = await dataQuery.CountAsync();

            var data = await dataQuery
                .Include(e => e.Clientes)
                .Include(e => e.Tramitadores)
                .Include(e => e.Productos)
                .Include(e => e.MultasDetalle)
                .OrderByDescending(e => e.Created_at)
                .ThenBy(e => e.Clientes.Identificacion)
                .Skip(page * length).Take(length).ToListAsync();

            return Ok(new
            {
                count,
                data = data.Select(e => new
                {
                    e.Id,
                    ClienteId = e.Clientes.Identificacion,
                    ClienteNombres = e.Clientes.Nombres,
                    ClienteApellidos = e.Clientes.Apellidos,
                    Clasificacion = e.Clasificacion.ToString(),
                    TramitadorCodigo = e.Tramitadores.Codigo,
                    TramitadorNombre = e.Tramitadores.Nombre,
                    ProductoId = e.Productos.Nombre,
                    ProductoNombre = e.Productos.Nombre,
                    Created_at = e.Created_at.ToString("d"),
                    Total = e.MultasDetalle.Sum(d => d.Valor),
                    Comparendos = e.MultasDetalle.Count()
                })
            });
        }

        public async Task<IHttpActionResult> Get(long id)
        {
            var multa = await db.Multas
                                    .Include(e => e.Clientes)
                                    .Include(e => e.Tramitadores)
                                    .Include(e => e.Productos)
                                    //.Include(e => e.MultasDetalle)
                                    .Where(e => e.Id == id)
                                    .FirstOrDefaultAsync();

            if (multa == null)
                return NotFound();

            var detalle = await db.MultasDetalle.Where(e => e.MultaId == id)
                            .OrderBy(e => e.Estado)
                            .Include(e => e.TipoComparendos)
                            .ToListAsync();

            double totalGastos = await db.Gastos
                                   .Where(e => e.Estado == EstadoGasto.Ejecutado &&
                                               e.TipoGasto == TipoGasto.Multa &&
                                               e.Referencia == multa.Id.ToString())
                                   .SumAsync(e => (double?)e.Valor) ?? 0;
            double totalIngresos = await db.Ingresos
                                    .Where(e => e.Estado == EstadoIngreso.Ejecutado &&
                                                e.TipoIngreso == TipoIngreso.Multa &&
                                                e.Referencia == multa.Id.ToString())
                                    .SumAsync(e => (double?)e.Valor) ?? 0;

            return Ok(new
            {
                Multa = multa,
                Cliente = new
                {
                    multa.Clientes.Identificacion,
                    multa.Clientes.Nombres,
                    multa.Clientes.Apellidos,
                    multa.Clientes.Celular,
                    multa.Clientes.Correo,
                    Fullname = multa.Clientes.Identificacion + " - " + multa.Clientes.Nombres + " " + multa.Clientes.Apellidos
                },
                Producto = new
                {
                    multa.Productos.Id,
                    multa.Productos.Nombre,
                    TipoValor = multa.Productos.TipoValor.ToString(),
                    multa.Productos.Valor,
                    multa.Productos.Costo,
                    multa.Productos.Activo
                },
                Tramitador = multa.Tramitadores,
                Detalle = detalle.Select(e => new
                {
                    e.ItemId,
                    e.MultaId,
                    e.TipoComparendoId,
                    e.TipoComparendos,
                    e.Comparendo,
                    e.Resolucion,
                    e.Estado,
                    EstadoTexto = e.Estado.ToString(),
                    e.ValorComparendo,
                    e.Porcentaje,
                    e.Valor,
                    e.Created_at,
                    //Created_at = e.Created_at.ToString("d"),
                    e.Updated_at,
                    e.EnProcesoPago
                }),
                TotalGastos = totalGastos,
                TotalIngresos = totalIngresos
            });
        }

        public async Task<IHttpActionResult> Post(MultasViewModel model)
        {
            if (ModelState.IsValid)
            {
                db.Multas.Add(model.Multa);
                await db.SaveChangesAsync();

                
                if (model.Detalle.Count > 0)
                {
                    await SaveDetalle(model.Multa.Id, model.Detalle);
                }

                await AddLog("Create", model.Multa.Id.ToString(), model);
                return Ok(model.Multa.Id);
            }

            return BadRequest(ModelState);
        }

        public async Task<IHttpActionResult> Put(MultasViewModel model)
        {
            if (ModelState.IsValid)
            {
                db.Entry(model.Multa).State = EntityState.Modified;
                db.Entry(model.Multa).Property(e => e.Created_at).IsModified = false;
                await db.SaveChangesAsync();

                await AddLog("Edit", model.Multa.Id.ToString(), model);

                await SaveDetalle(model.Multa.Id, model.Detalle);
                return Ok(model);
            }

            return BadRequest(ModelState);
        }

        private async Task SaveDetalle(long m, List<MultasDetalle> detalle)
        {
            //Items que viene de la base de datos
            var currentDetalle = await db.MultasDetalle.Where(e => e.MultaId == m).ToListAsync();
            int nro = (currentDetalle.Max(e => (int?)e.ItemId) ?? 0) + 1;

            //Items de ViewModel o que vienen del formulario HTML
            int[] idsItems = detalle.Select(e => e.ItemId).ToArray();

            //Selecciona que estan en la base de datos, pero que se eliminaron desde el HTML
            var itemsToDelete = currentDetalle.Where(e => !idsItems.Contains(e.ItemId)).ToList();

            if (itemsToDelete.Count > 0)
            {
                db.MultasDetalle.RemoveRange(itemsToDelete);
                await db.SaveChangesAsync();
            }

            foreach (var item in detalle)
            {
                //Si tiene el Item en cero es nuevo registro

                if (item.ItemId == 0)
                {
                    item.MultaId = m;
                    item.ItemId = nro;

                    db.MultasDetalle.Add(item);
                    nro++;
                }
                else
                {
                    var editDetalle = currentDetalle.Where(e => e.ItemId == item.ItemId).FirstOrDefault();
                    //Validar que solo sean comparendos pendientes
                    editDetalle.TipoComparendoId = item.TipoComparendoId;
                    editDetalle.Comparendo = item.Comparendo;
                    editDetalle.Resolucion = item.Resolucion;
                    editDetalle.ValorComparendo = item.ValorComparendo;
                    editDetalle.Porcentaje = item.Porcentaje;
                    editDetalle.Estado = item.Estado;
                    editDetalle.Valor = item.Valor;
                    editDetalle.EnProcesoPago = item.EnProcesoPago;
                    db.Entry(editDetalle).State = EntityState.Modified;
                    db.Entry(editDetalle).Property(e => e.Created_at).IsModified = false;
                }

                await db.SaveChangesAsync();
            }
        }

        [HttpGet]
        [Route("api/Multas/Clasificaciones")]
        public IHttpActionResult Clasificaciones()
        {
            var listado = Fn.EnumToIEnumarable<Clasificacion>().ToList();
            return Ok(listado);
        }

        [HttpGet]
        [Route("api/Multas/EstadosComparendo")]
        public IHttpActionResult EstadosComparendo()
        {
            var listado = Fn.EnumToIEnumarable<EstadoComparendo>().ToList();
            return Ok(listado);
        }
    }
}
