﻿using System;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http;
using TramiT.Classes;
using TramiT.Models;
using TramiT.Models.ViewModel;

namespace TramiT.Controllers
{
    public class ListadosDetalleController : ApiBaseController
    {
        private TramiTDBContext db = new TramiTDBContext();

        public async Task<IHttpActionResult> Get(long l, int id)
        {
            var detalle = await db.ListadosDetalle
                                    .Include(e => e.MultasDetalle)
                                    .Where(e => e.ListadoId == l && e.Id == id).FirstOrDefaultAsync();

            if (detalle == null)
                return NotFound();

            return Ok(detalle);
        }

        [HttpGet]
        [Route("api/ListadosDetalle/GetByMulta/{MultaId}/{ItemId}")]
        public async Task<IHttpActionResult> GetByMulta(long MultaId, int ItemId)
        {
            var dataQuery = db.ListadosDetalle
                            .Where(e => e.MultaId == MultaId && e.MultaItemId == ItemId)
                            .AsQueryable();

            var data = await dataQuery
                .Include(e => e.Listados)
                .OrderByDescending(e => e.Created_at)
                .ThenBy(e => e.Estado)
                .ToListAsync();


            return Ok(data.Select(l => new
            {
                l.ListadoId,
                ListadoTitulo = l.Listados.Titulo,
                EstadoListado = l.Estado.ToString(),
                Created_at = l.Created_at.ToString("d"),
                Updated_at = l.Updated_at.ToString("d"),
                Estado = l.Estado.ToString(),
                l.Pagado,
                l.Nota
            }).ToList());

        }

        public async Task<IHttpActionResult> Post(ListadosDetalleViewModel model)
        {
            if (ModelState.IsValid)
            {
                var currentDetalle = await db.ListadosDetalle.Where(e => e.ListadoId == model.ListadoId).ToListAsync();
                int nro = (currentDetalle.Max(e => (int?)e.Id) ?? 0) + 1;

                foreach (var item in model.Detalle)
                {
                    int countComparendo = await db.ListadosDetalle
                        .Where(e => e.ListadoId == model.ListadoId &&
                                    e.MultaId == item.MultaId &&
                                    e.MultaItemId == item.MultaItemId).CountAsync();
                    if (countComparendo == 0)
                    {
                        item.ListadoId = model.ListadoId;
                        item.Id = nro;
                        db.ListadosDetalle.Add(item);

                        nro++;
                    }
                }

                await db.SaveChangesAsync();
                await AddLog("Edit", model.ListadoId.ToString(), model);

                return Ok(model.ListadoId);
            }

            return BadRequest(ModelState);
        }

        public async Task<IHttpActionResult> Put(ListadosDetalleEditViewModel model)
        {
            if (ModelState.IsValid)
            {
                var listadoDetalle = new ListadosDetalle
                {
                    ListadoId = model.ListadoId,
                    Id = model.Id,
                    Estado = model.Estado,
                    Nota = model.Nota,
                    Updated_at = DateTime.Now,
                    Pagado = model.Pagado
                };
                db.ListadosDetalle.Attach(listadoDetalle);
                db.Entry(listadoDetalle).Property("Estado").IsModified = true;
                db.Entry(listadoDetalle).Property("Nota").IsModified = true;
                db.Entry(listadoDetalle).Property("Updated_at").IsModified = true;
                db.Entry(listadoDetalle).Property("Pagado").IsModified = true;

                await db.SaveChangesAsync();

                var multaDetalle = new MultasDetalle
                {
                    MultaId = model.MultaId,
                    ItemId = model.MultaItemId,
                    Estado = model.EstadoComparendo,
                    Updated_at = DateTime.Now
                };
                db.MultasDetalle.Attach(multaDetalle);
                db.Entry(multaDetalle).Property("Estado").IsModified = true;
                db.Entry(multaDetalle).Property("Updated_at").IsModified = true;

                await db.SaveChangesAsync();

                return Ok(model);
            }

            return BadRequest(ModelState);
        }

        [HttpGet]
        [Route("api/ListadosDetalle/Estados")]
        public IHttpActionResult Estados()
        {
            var listado = Fn.EnumToIEnumarable<EstadoListadoDetalle>().ToList();
            return Ok(listado);
        }
    }
}
