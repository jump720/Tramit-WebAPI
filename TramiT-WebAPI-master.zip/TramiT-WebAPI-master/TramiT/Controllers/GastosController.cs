﻿using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http;
using TramiT.Classes;
using TramiT.Models;
using TramiT.Models.ViewModel;

namespace TramiT.Controllers
{
    public class GastosController : ApiBaseController
    {
        private TramiTDBContext db = new TramiTDBContext();

        public async Task<IHttpActionResult> Get(int page = 0, int length = 20, string search = "", string referencia = "", TipoGasto? tipo = null)
        {
            var dataQuery = db.Gastos.AsQueryable();

            if (!string.IsNullOrWhiteSpace(referencia))
            {
                string value = referencia.ToLower().Trim();
                dataQuery = dataQuery.Where(e => e.Referencia.ToLower() == value);
            }

            if (!string.IsNullOrWhiteSpace(search))
            {
                string value = search.ToLower().Trim();
                dataQuery = dataQuery.Where(e => e.Descripcion.ToLower().ToString().Contains(value) );
            }

            if (tipo != null)
            {
                dataQuery = dataQuery.Where(e => e.TipoGasto == tipo);
            }

            int count = await dataQuery.CountAsync();

            var data = await dataQuery
                .OrderByDescending(e => e.Created_at)
                .ThenBy(e => e.Id)
                .ThenBy(e => e.Estado)
                .Skip(page * length).Take(length).ToListAsync();

            return Ok(new
            {
                count,
                data = data.Select(e => new
                {
                    e.Id,
                    e.Descripcion,
                    e.Referencia,
                    e.Valor,
                    e.Nota,
                    Estado = e.Estado.ToString(),
                    TipoGasto = e.TipoGasto.ToString(),
                    Created_at = e.Created_at.ToString("d"),
                    Updated_at = e.Updated_at.ToString("d"),
                    e.Created_by,
                    e.Updated_by
                })
            });
        }       

        public async Task<IHttpActionResult> Get(long id)
        {
            var gasto = await db.Gastos.Where(e => e.Id == id).FirstOrDefaultAsync();

            if (gasto == null)
                return NotFound();

            return Ok(gasto);
        }

        public async Task<IHttpActionResult> Post(Gastos model)
        {
            if (ModelState.IsValid)
            {
                db.Gastos.Add(model);
                await db.SaveChangesAsync();

                await AddLog("Create", model.Id.ToString(), model);

                return Ok();
            }
            return BadRequest(ModelState);
        }

        public async Task<IHttpActionResult> Put(Gastos model)
        {
            if (ModelState.IsValid)
            {
                db.Entry(model).State = EntityState.Modified;
                db.Entry(model).Property(e => e.Created_at).IsModified = false;
                await db.SaveChangesAsync();

                await AddLog("Edit", model.Id.ToString(), model);
                return Ok(model);
            }

            return BadRequest(ModelState);
        }

        [HttpPost]
        [Route("api/Gastos/Anular/{id}")]
        public async Task<IHttpActionResult> Anular(long id)
        {
            var gasto = await db.Gastos.Where(e => e.Id == id).FirstOrDefaultAsync();

            if (gasto == null)
                return NotFound();

            string idS = id.ToString();
            int cierreCount = db.CierreDetalle.Include(e => e.Cierre)
                    .Where(e => e.Cierre.Estado != EstadoCierre.Anulado && e.TipoMovimiento == TipoMovimiento.Gasto && e.MovimientoId == idS).Count();
            
            if (gasto.Estado == EstadoGasto.Ejecutado && cierreCount == 0)
            {
                gasto.Estado = EstadoGasto.Anulado;
                db.Entry(gasto).State = EntityState.Modified;
                db.Entry(gasto).Property(e => e.Created_at).IsModified = false;
                await db.SaveChangesAsync();

                await AddLog("Anular", gasto.Id.ToString(), gasto);
                return Ok(gasto.Id);
            }

            string errortext = "Gasto no puede ser anulado ";
            if (cierreCount > 0)
            {
                errortext += "(pertecene a un cierre)";
            }
            return BadRequest(errortext);
        }

        //[HttpGet]
        //[Route("api/Gastos/GetByTipo")]
        //public async Task<IHttpActionResult> GetByTipo(TipoGasto Tipo, string referencia, int page = 0, int length = 20, string search = "")
        //{
        //    var dataQuery = db.Gastos
        //                    .Where(e => e.Referencia.ToLower() == referencia.ToLower().Trim() && e.TipoGasto == Tipo)
        //                    .AsQueryable();            

        //    if (!string.IsNullOrWhiteSpace(search))
        //    {
        //        string value = search.ToLower().Trim();
        //        dataQuery = dataQuery.Where(e => e.Descripcion.ToLower().ToString().Contains(value));
        //    }

        //    int count = await dataQuery.CountAsync();

        //    var data = await dataQuery
        //        .OrderByDescending(e => e.Created_at)
        //        .ThenBy(e => e.Id)
        //        .ThenBy(e => e.Estado)
        //        .Skip(page * length).Take(length).ToListAsync();

        //    return Ok(new
        //    {
        //        count,
        //        data = data.Select(e => new
        //        {
        //            e.Id,
        //            e.Descripcion,
        //            e.Referencia,
        //            e.Valor,
        //            e.Nota,
        //            Estado = e.Estado.ToString(),
        //            TipoGasto = e.TipoGasto.ToString(),
        //            Created_at = e.Created_at.ToString("d"),
        //            Updated_at = e.Updated_at.ToString("d")
        //        })
        //    });
        //}

        [HttpGet]
        [Route("api/Gastos/Estados")]
        public IHttpActionResult Estados()
        {
            var tipoValor = Fn.EnumToIEnumarable<EstadoGasto>().ToList();
            return Ok(tipoValor);
        }

        [HttpGet]
        [Route("api/Gastos/TiposGasto")]
        public IHttpActionResult TiposGasto()
        {
            var listado = Fn.EnumToIEnumarable<TipoGasto>().ToList();
            return Ok(listado);
        }
    }
}
