﻿using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Microsoft.AspNet.Identity.Owin;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
//https://www.yogihosting.com/aspnet-core-identity-roles/#add-remove-users
namespace TramiT.Controllers
{
    public class RoleController : ApiBaseController
    {
        public RoleController() { }

        private ApplicationRoleManager _roleManager;
        public RoleController(ApplicationRoleManager roleMgr)
        {
            RoleManager = roleMgr;
        }

        public ApplicationRoleManager RoleManager
        {
            get
            {
                return _roleManager ?? HttpContext.Current.Request.GetOwinContext().Get<ApplicationRoleManager>();
            }
            private set
            {
                _roleManager = value;
            }
        }

        public IHttpActionResult Get() => Ok(RoleManager.Roles);

        public async Task<IHttpActionResult> Get(string id)
        {
            var role = await RoleManager.FindByIdAsync(id);

            if (role == null)
                return NotFound();

            return Ok(new
            {
                role.Id,
                role.Name
            });
        }

        public async Task<IHttpActionResult> Post([Required]string name)
        {
            if (ModelState.IsValid)
            {
                IdentityResult result = await RoleManager.CreateAsync(new IdentityRole(name));
                if (result.Succeeded)
                    return Ok();
                else
                    return GetErrorResult(result);
            }
            return BadRequest(ModelState);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                RoleManager.Dispose();
            }

            base.Dispose(disposing);
        }

        #region helpers

        private IHttpActionResult GetErrorResult(IdentityResult result)
        {
            if (result == null)
            {
                return InternalServerError();
            }

            if (!result.Succeeded)
            {
                if (result.Errors != null)
                {
                    foreach (string error in result.Errors)
                    {
                        ModelState.AddModelError("", error);
                    }
                }

                if (ModelState.IsValid)
                {
                    // No ModelState errors are available to send, so just return an empty BadRequest.
                    return BadRequest();
                }

                return BadRequest(ModelState);
            }

            return null;
        }

        #endregion
    }
}
