﻿using Microsoft.AspNet.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using TramiT.Classes;
using TramiT.Models;
namespace TramiT.Controllers
{
    [Authorize]
    public class ApiBaseController : ApiController
    {
        [NonAction]
        public async Task AddLog(string ActionName, string Key, object data)
        {
            string ControllerName = ControllerContext.ControllerDescriptor.ControllerName;

            Logs log = new Logs()
            {
                User = User.Identity.GetUserName(),
                Data = Fn.GetJsonString(data),
                ControllerName = ControllerName,
                ActionName = ActionName,
                KeyData = Key
            };
            
            using(var db = new TramiTDBContext())
            {
                db.Logs.Add(log);
                await db.SaveChangesAsync();
            }

        }

        public class EnumData
        {
            public int Value { get; set; }
            public string Name { get; set; }
        }

        public static IEnumerable<EnumData> EnumToIEnumarable<T>()
        {
            if (typeof(T).BaseType != typeof(Enum))
                throw new InvalidCastException();

            var enumValues = (T[])Enum.GetValues(typeof(T));
            var enumList = from value in enumValues
                           select new EnumData { Value = Convert.ToInt32(value), Name = value.ToString().Replace("__", "-").Replace("_", " ") };

            return enumList;
        }
    }
}