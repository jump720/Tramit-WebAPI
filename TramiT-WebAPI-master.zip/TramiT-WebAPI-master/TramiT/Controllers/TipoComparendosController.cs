﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using TramiT.Models;

namespace TramiT.Controllers
{
    public class TipoComparendosController : ApiBaseController
    {
        private TramiTDBContext db = new TramiTDBContext();

        public async Task<IHttpActionResult> Get(int page = 0, int length = 20, string search = "")
        {
            var dataQuery = db.TipoComparendos.AsQueryable();

            if (!string.IsNullOrWhiteSpace(search))
            {
                string value = search.ToLower().Trim();
                dataQuery = dataQuery.Where(e => e.Nombre.ToLower().ToString().Contains(value));
            }

            int count = await dataQuery.CountAsync();

            var data = await dataQuery
                .OrderByDescending(e => e.Nombre)
                .ThenBy(e => e.Nombre)
                .Skip(page * length).Take(length).ToListAsync();

            return Ok(new { count, data });
        }

        public async Task<IHttpActionResult> Get(int id)
        {
            var tipo = await db.TipoComparendos.Where(e => e.Id == id).FirstOrDefaultAsync();

            if (tipo == null)
                return NotFound();

            return Ok(tipo);
        }

        public async Task<IHttpActionResult> Post(TipoComparendos model)
        {
            if (ModelState.IsValid)
            {
                db.TipoComparendos.Add(model);
                await db.SaveChangesAsync();

                await AddLog("Create", model.Id.ToString(), model);
                return Ok(model);
            }

            return BadRequest(ModelState);
        }

        public async Task<IHttpActionResult> Put(TipoComparendos model)
        {
            if (ModelState.IsValid)
            {
                db.Entry(model).State = EntityState.Modified;
                await db.SaveChangesAsync();

                await AddLog("Edit", model.Id.ToString(), model);
                return Ok(model);
            }

            return BadRequest(ModelState);
        }

        public async Task<IHttpActionResult> Delete(int id)
        {
            TipoComparendos tipo = await db.TipoComparendos
                                    .Include(e => e.MultasDetalle)
                                    .Where(e => e.Id == id).FirstOrDefaultAsync();
            if (tipo == null)
                return NotFound();

            //Validar que no tenga multas
            if (tipo.MultasDetalle.Count == 0)
            {
                db.TipoComparendos.Remove(tipo);
                await db.SaveChangesAsync();

                await AddLog("Delete", id.ToString(), tipo);
                return Ok("Tipo de comparendo eliminado con exito");
            }
            return BadRequest("Tipo de comparendo no puede ser eliminado, tiene multas registradas");
        }
    }
}
