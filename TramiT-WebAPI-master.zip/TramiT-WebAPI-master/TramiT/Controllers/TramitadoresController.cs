﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using TramiT.Models;

namespace TramiT.Controllers
{
    public class TramitadoresController : ApiBaseController
    {
        private TramiTDBContext db = new TramiTDBContext();


        public async Task<IHttpActionResult> Get(int page = 0, int length = 20, string search = "")
        {
            var dataQuery = db.Tramitadores.AsQueryable();

            if (!string.IsNullOrWhiteSpace(search))
            {
                string value = search.ToLower().Trim();
                dataQuery = dataQuery.Where(e => e.Nombre.ToLower().ToString().Contains(value));
            }

            int count = await dataQuery.CountAsync();

            var data = await dataQuery
                .OrderByDescending(e => e.Codigo)
                .ThenBy(e => e.Nombre)
                .Skip(page * length).Take(length).ToListAsync();

            return Ok(new { count, data });
        }

        public async Task<IHttpActionResult> Get(string id)
        {
            var tramitador = await db.Tramitadores.Where(e => e.Codigo == id).FirstOrDefaultAsync();

            if (tramitador == null)
                return NotFound();

            return Ok(tramitador);
        }

        public async Task<IHttpActionResult> Post(Tramitadores model)
        {

            if (!IsCodigoAvailable(model.Codigo))
            {
                ModelState.AddModelError("Codigo", "El código de tramitador ya existe");
            }

            if (ModelState.IsValid)
            {
                db.Tramitadores.Add(model);
                await db.SaveChangesAsync();

                await AddLog("Create", model.Codigo, model);
                return Ok(model);
            }

            return BadRequest(ModelState);
        }

        public async Task<IHttpActionResult> Put(Tramitadores model)
        {
            if (ModelState.IsValid)
            {
                db.Entry(model).State = EntityState.Modified;
                db.Entry(model).Property(e => e.Created_at).IsModified = false;
                await db.SaveChangesAsync();

                await AddLog("Edit", model.Codigo, model);
                return Ok(model);
            }

            return BadRequest(ModelState);
        }

        public async Task<IHttpActionResult> Delete(string id)
        {
            Tramitadores tramitador = await db.Tramitadores
                    .Include(e => e.Tramites)
                    .Where(e => e.Codigo == id).FirstOrDefaultAsync();
            if (tramitador == null)
                return NotFound();

            //Validar que no tenga tramites
            if (tramitador.Tramites.Count == 0)
            {
                db.Tramitadores.Remove(tramitador);
                await db.SaveChangesAsync();

                await AddLog("Delete", id, tramitador);
                return Ok("Tramitador eliminado con exito");
            }
            return BadRequest("Tramitador no puede ser eliminado, tiene tramites registrados");
        }

        private bool IsCodigoAvailable(string codigo)
        {
            return !db.Tramitadores.Any(e => e.Codigo == codigo);
        }

    }
}
