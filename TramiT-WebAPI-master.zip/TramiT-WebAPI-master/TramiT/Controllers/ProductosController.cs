﻿using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http;
using TramiT.Classes;
using TramiT.Models;

namespace TramiT.Controllers
{
    public class ProductosController : ApiBaseController
    {

        private TramiTDBContext db = new TramiTDBContext();

        public async Task<IHttpActionResult> Get(int page = 0, int length = 20, string search = "")
        {
            var dataQuery = db.Productos.AsQueryable();

            if (!string.IsNullOrWhiteSpace(search))
            {
                string value = search.ToLower().Trim();
                dataQuery = dataQuery.Where(e => e.Nombre.ToLower().ToString().Contains(value));
            }

            int count = await dataQuery.CountAsync();

            var data = await dataQuery
                .OrderByDescending(e => e.Nombre)
                .ThenBy(e => e.Nombre)
                .Skip(page * length).Take(length).ToListAsync();

            return Ok(new
            {
                count,
                data = data.Select(e => new
                {
                    e.Id,
                    e.Nombre,
                    TipoValor = e.TipoValor.ToString(),
                    TipoProducto = e.TipoProducto.ToString(),
                    e.Valor,
                    e.Costo,
                    e.Activo
                })
            });
        }

        public async Task<IHttpActionResult> Get(int id)
        {
            var producto = await db.Productos.Where(e => e.Id == id).FirstOrDefaultAsync();

            if (producto == null)
                return NotFound();

            return Ok(producto);
        }

        public async Task<IHttpActionResult> Post(Productos model)
        {
            if (ModelState.IsValid)
            {
                db.Productos.Add(model);
                await db.SaveChangesAsync();

                await AddLog("Create", model.Id.ToString(), model);
                return Ok(model);
            }

            return BadRequest(ModelState);
        }

        public async Task<IHttpActionResult> Put(Productos model)
        {
            if (ModelState.IsValid)
            {
                db.Entry(model).State = EntityState.Modified;
                await db.SaveChangesAsync();

                await AddLog("Edit", model.Id.ToString(), model);
                return Ok(model);
            }

            return BadRequest(ModelState);
        }

        [HttpGet]
        [Route("api/Productos/GetByTipo/{Tipo}")]
        public async Task<IHttpActionResult> GetByTipo(TipoProducto Tipo)
        {
            var dataQuery = db.Productos
                    .Where(e => e.TipoProducto == Tipo && e.Activo == true)
                    .AsQueryable();

            var data = await dataQuery
                .OrderByDescending(e => e.Nombre)
                .ThenBy(e => e.Nombre).ToListAsync();

            return Ok(data.Select(e => new
            {
                e.Id,
                e.Nombre,
                TipoValor = e.TipoValor.ToString(),
                TipoProducto = e.TipoProducto.ToString(),
                e.Valor,
                e.Costo,
                e.Activo
            }));
        }

        [HttpPost]
        [Route("api/Productos/Toggle/{id}")]
        public async Task<IHttpActionResult> Toggle(int id)
        {
            Productos producto = await db.Productos.Where(e => e.Id == id).FirstOrDefaultAsync();
            if (producto == null)
                return NotFound();

            producto.Activo = !producto.Activo;

            db.Entry(producto).State = EntityState.Modified;
            await db.SaveChangesAsync();

            await AddLog("CambioEstado", id.ToString(), producto);

            return Ok("Se cambio el estado del producto con exito!");
        }

        [HttpGet]
        [Route("api/Productos/TipoValor")]
        public IHttpActionResult TipoValor()
        {
            var tipoValor = Fn.EnumToIEnumarable<TipoValor>().ToList();

            return Ok(tipoValor);
        }

        [HttpGet]
        [Route("api/Productos/TipoProducto")]
        public IHttpActionResult TipoProducto()
        {
            var listado = Fn.EnumToIEnumarable<TipoProducto>().ToList();
            return Ok(listado);
        }
    }
}
