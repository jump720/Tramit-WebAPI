﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using TramiT.Classes;
using TramiT.Models;

namespace TramiT.Controllers
{
    public class IngresosController : ApiBaseController
    {
        private TramiTDBContext db = new TramiTDBContext();

        public async Task<IHttpActionResult> Get(int page = 0, int length = 20, string search = "", string referencia = "", TipoIngreso? tipo = null)
        {
            var dataQuery = db.Ingresos.AsQueryable();

            if (!string.IsNullOrWhiteSpace(referencia))
            {
                string value = referencia.ToLower().Trim();
                dataQuery = dataQuery.Where(e => e.Referencia.ToLower() == value);
            }

            if (!string.IsNullOrWhiteSpace(search))
            {
                string value = search.ToLower().Trim();
                dataQuery = dataQuery.Where(e => e.Descripcion.ToLower().ToString().Contains(value));
            }

            if (tipo != null)
            {
                dataQuery = dataQuery.Where(e => e.TipoIngreso == tipo);
            }

            int count = await dataQuery.CountAsync();

            var data = await dataQuery
                .OrderByDescending(e => e.Created_at)
                .ThenBy(e => e.Id)
                .ThenBy(e => e.Estado)
                .Skip(page * length).Take(length).ToListAsync();

            return Ok(new
            {
                count,
                data = data.Select(e => new
                {
                    e.Id,
                    e.Descripcion,
                    e.Referencia,
                    e.Valor,
                    e.Nota,
                    Estado = e.Estado.ToString(),
                    TipoIngreso = e.TipoIngreso.ToString(),
                    Created_at = e.Created_at.ToString("d"),
                    Updated_at = e.Updated_at.ToString("d")
                })
            });
        }

        public async Task<IHttpActionResult> Get(long id)
        {
            var ingreso = await db.Ingresos.Where(e => e.Id == id).FirstOrDefaultAsync();

            if (ingreso == null)
                return NotFound();

            return Ok(ingreso);
        }

        public async Task<IHttpActionResult> Post(Ingresos model)
        {
            if (ModelState.IsValid)
            {
                db.Ingresos.Add(model);
                await db.SaveChangesAsync();

                await AddLog("Create", model.Id.ToString(), model);

                return Ok();
            }
            return BadRequest(ModelState);
        }

        public async Task<IHttpActionResult> Put(Ingresos model)
        {
            if (ModelState.IsValid)
            {
                db.Entry(model).State = EntityState.Modified;
                db.Entry(model).Property(e => e.Created_at).IsModified = false;
                await db.SaveChangesAsync();

                await AddLog("Edit", model.Id.ToString(), model);
                return Ok(model);
            }

            return BadRequest(ModelState);
        }

        [HttpPost]
        [Route("api/Ingresos/Anular/{id}")]
        public async Task<IHttpActionResult> Anular(long id)
        {
            var ingreso = await db.Ingresos.Where(e => e.Id == id).FirstOrDefaultAsync();

            if (ingreso == null)
                return NotFound();

            string idS = id.ToString();
            int cierreCount = db.CierreDetalle.Include(e => e.Cierre)
                    .Where(e => e.Cierre.Estado != EstadoCierre.Anulado && e.TipoMovimiento == TipoMovimiento.Ingreso && e.MovimientoId == idS).Count();

            if (ingreso.Estado == EstadoIngreso.Ejecutado && cierreCount == 0)
            {
                ingreso.Estado = EstadoIngreso.Anulado;
                db.Entry(ingreso).State = EntityState.Modified;
                db.Entry(ingreso).Property(e => e.Created_at).IsModified = false;
                await db.SaveChangesAsync();

                await AddLog("Anular", ingreso.Id.ToString(), ingreso);
                return Ok(ingreso.Id);
            }

            string errortext = "Ingreso no puede ser anulado ";
            if (cierreCount > 0)
            {
                errortext += "(pertecene a un cierre)";
            }
            return BadRequest(errortext);
        }

        [HttpGet]
        [Route("api/Ingresos/GetByTipo")]
        public async Task<IHttpActionResult> GetByTipo(TipoIngreso Tipo, string referencia, int page = 0, int length = 20, string search = "")
        {
            var dataQuery = db.Ingresos
                            .Where(e => e.Referencia.ToLower() == referencia.ToLower().Trim() && e.TipoIngreso == Tipo)
                            .AsQueryable();

            if (!string.IsNullOrWhiteSpace(search))
            {
                string value = search.ToLower().Trim();
                dataQuery = dataQuery.Where(e => e.Descripcion.ToLower().ToString().Contains(value));
            }

            int count = await dataQuery.CountAsync();

            var data = await dataQuery
                .OrderByDescending(e => e.Created_at)
                .ThenBy(e => e.Id)
                .ThenBy(e => e.Estado)
                .Skip(page * length).Take(length).ToListAsync();

            return Ok(new
            {
                count,
                data = data.Select(e => new
                {
                    e.Id,
                    e.Descripcion,
                    e.Referencia,
                    e.Valor,
                    e.Nota,
                    Estado = e.Estado.ToString(),
                    TipoIngreso = e.TipoIngreso.ToString(),
                    Created_at = e.Created_at.ToString("d"),
                    Updated_at = e.Updated_at.ToString("d")
                })
            });
        }

        [HttpGet]
        [Route("api/Ingresos/Estados")]
        public IHttpActionResult Estados()
        {
            var tipoValor = Fn.EnumToIEnumarable<EstadoIngreso>().ToList();
            return Ok(tipoValor);
        }

        [HttpGet]
        [Route("api/Ingresos/TiposIngresos")]
        public IHttpActionResult TiposIngresos()
        {
            var listado = Fn.EnumToIEnumarable<TipoIngreso>().ToList();
            return Ok(listado);
        }
    }
}
