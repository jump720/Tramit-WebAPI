﻿using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http;
using TramiT.Models;
using TramiT.Models.ViewModel;

namespace TramiT.Controllers
{

    public class CierreController : ApiBaseController
    {
        private TramiTDBContext db = new TramiTDBContext();

        public async Task<IHttpActionResult> Get(int page = 0, int length = 20, string search = "")
        {
            var dataQuery = db.Cierre.AsQueryable();

            if (!string.IsNullOrWhiteSpace(search))
            {
                string value = search.ToLower().Trim();
                dataQuery = dataQuery.Where(e => e.Id.ToString().Contains(value) || e.Titulo.ToLower().ToString().Contains(value));
            }

            int count = await dataQuery.CountAsync();

            var data = await dataQuery
                .Include(e => e.CierreDetalle)
                .OrderBy(e => e.Estado)
                .ThenByDescending(e => e.Created_at)
                .Skip(page * length).Take(length).ToListAsync();

            return Ok(new
            {
                count,
                data = data.Select(e => new
                {
                    e.Id,
                    e.Titulo,
                    Estado = e.Estado.ToString(),
                    FechaInicio = e.FechaInicio.ToString("d"),
                    FechaFin = e.FechaFin.ToString("d"),
                    Created_at = e.Created_at.ToString("d"),
                    Updated_at = e.Updated_at.ToString("d"),
                    Registros = e.CierreDetalle.Count()
                })
            });
        }

        public async Task<IHttpActionResult> Get(long id)
        {
            var cierre = await db.Cierre.Where(e => e.Id == id).FirstOrDefaultAsync();

            if (cierre == null)
                return NotFound();

            var detalle = await db.CierreDetalleVW.Where(e => e.CierreId == id)
                            .OrderBy(e => e.TipoMovimiento)
                            .ThenByDescending(e => e.MovimientoId)
                            .ToListAsync();

            return Ok(new
            {
                Cierre = new
                {
                    cierre.Id,
                    cierre.Titulo,
                    Estado = cierre.Estado.ToString(),
                    cierre.FechaInicio,
                    cierre.FechaFin,
                    cierre.Created_at,
                    cierre.Updated_at
                },
                Detalle = detalle.Select(e => new
                {
                    e.Id,
                    e.CierreId,
                    TipoMovimiento = e.TipoMovimiento.ToString(),
                    e.MovimientoId,
                    Created_at = e.Created_at.ToString("d"),
                    Updated_at = e.Updated_at.ToString("d"),
                    e.Created_by,
                    e.Updated_by,
                    e.MovimientoDesc,
                    e.MovimientoValor,
                    MovimientoCreated_at = e.MovimientoCreated_at.ToString("d"),
                    e.MovimientoEstado,
                    MovimientoTipo = e.MovimientoTipo.ToString(),
                    e.Referencia,
                    e.ClienteId,
                    e.ClienteNombre,
                    e.TramitadorId,
                    e.TramitadorNombre,
                    EstadoMovimiento = e.EstadoMovimiento.ToString(),
                    e.Producto,
                })
            });

        }
        public async Task<IHttpActionResult> Post(CierreViewModel model)
        {
            if (ModelState.IsValid)
            {
                db.Cierre.Add(model.Cierre);
                await db.SaveChangesAsync();

                await AddLog("Create", model.Cierre.Id.ToString(), model);
                if (model.Detalle.Count > 0)
                {
                    await SaveDetalle(model.Cierre.Id, model.Detalle);
                }

                return Ok(model.Cierre.Id);
            }

            return BadRequest(ModelState);
        }

        [HttpPost]
        [Route("api/Cierre/Pendiente/{id}")]
        public async Task<IHttpActionResult> Pendiente(long id)
        {
            var cierre = await db.Cierre.Where(e => e.Id == id).FirstOrDefaultAsync();

            if (cierre == null)
                return NotFound();

            if (cierre.Estado == EstadoCierre.Completado)
            {
                cierre.Estado = EstadoCierre.Pendiente;
                db.Entry(cierre).State = EntityState.Modified;
                db.Entry(cierre).Property(e => e.Created_at).IsModified = false;
                await db.SaveChangesAsync();
                await AddLog("Pendiente", cierre.Id.ToString(), cierre);
                return Ok(cierre.Id);
            }

            ModelState.AddModelError("", "Cierre no puede ser puesto como pendiente");
            return BadRequest(ModelState);
        }

        [HttpPost]
        [Route("api/Cierre/Completar/{id}")]
        public async Task<IHttpActionResult> Completar(long id)
        {
            var cierre = await db.Cierre.Where(e => e.Id == id).FirstOrDefaultAsync();

            if (cierre == null)
                return NotFound();

            if (cierre.Estado == EstadoCierre.Pendiente)
            {
                cierre.Estado = EstadoCierre.Completado;
                db.Entry(cierre).State = EntityState.Modified;
                db.Entry(cierre).Property(e => e.Created_at).IsModified = false;
                await db.SaveChangesAsync();
                await AddLog("Completado", cierre.Id.ToString(), cierre);
                return Ok(cierre.Id);
            }

            ModelState.AddModelError("", "Cierre no puede ser puesto como compleado");
            return BadRequest(ModelState);
        }

        [HttpPost]
        [Route("api/Cierre/Anular/{id}")]
        public async Task<IHttpActionResult> Anular(long id)
        {
            var cierre = await db.Cierre.Where(e => e.Id == id).FirstOrDefaultAsync();

            if (cierre == null)
                return NotFound();

            if (cierre.Estado == EstadoCierre.Pendiente)
            {
                cierre.Estado = EstadoCierre.Anulado;
                db.Entry(cierre).State = EntityState.Modified;
                db.Entry(cierre).Property(e => e.Created_at).IsModified = false;
                await db.SaveChangesAsync();
                await AddLog("Anulado", cierre.Id.ToString(), cierre);
                return Ok(cierre.Id);
            }

            ModelState.AddModelError("", "Cierre no puede ser puesto como anulado");
            return BadRequest(ModelState);
        }

        private async Task SaveDetalle(long c, List<CierreDetalle> detalle)
        {
            int nro = 1;
            foreach (var item in detalle)
            {
                //Si tiene el Item en cero es nuevo registro
                if (item.Id == 0)
                {
                    item.CierreId = c;
                    item.Id = nro;

                    db.CierreDetalle.Add(item);
                    nro++;
                }

                await db.SaveChangesAsync();
            }
        }

    }
}
