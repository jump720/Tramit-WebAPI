﻿using System;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http;
using TramiT.Models;
using TramiT.Models.ViewModel;

namespace TramiT.Controllers
{
    public class CierreDetalleController : ApiBaseController
    {
        private TramiTDBContext db = new TramiTDBContext();

        [HttpGet]
        [Route("api/CierreDetalle/Gastos/getPendientes")]
        public async Task<IHttpActionResult> GetGastosPendientes(string inicio, string fin)
        {
            var fechaInicio = Convert.ToDateTime(inicio.ToLower().Trim()).Date;
            var fechaFin = Convert.ToDateTime(fin.ToLower().Trim()).Date;
            //Gastos entre las fechas (Agrupar por tipo de gasto) y que no este en otro cierre
            var gastos = await db.GastosPendientesCierre
                             .Where(e => e.Estado == EstadoGasto.Ejecutado && DbFunctions.TruncateTime(e.Created_at) >= fechaInicio && DbFunctions.TruncateTime(e.Created_at) <= fechaFin)
                             .OrderByDescending(e => e.TipoGasto)
                             .ToListAsync();

            return Ok(gastos.Select(e => new
            {
                e.Id,
                e.ClienteId,
                e.ClienteNombre,
                Created_at = e.Created_at.ToString("d"),
                Updated_at = e.Updated_at.ToString("d"),
                e.Descripcion,
                Estado = e.Estado.ToString(),
                TipoGasto = e.TipoGasto.ToString(),
                e.TramitadorId,
                e.TramitadorNombre,
                e.Valor,
                e.Producto,
                e.Referencia,
                TipoMovimiento = TipoMovimiento.Gasto
            }));
        }

        [HttpGet]
        [Route("api/CierreDetalle/Ingresos/getPendientes")]
        public async Task<IHttpActionResult> GetIngresosPendientes(string inicio, string fin)
        {
            var fechaInicio = Convert.ToDateTime(inicio.ToLower().Trim()).Date;
            var fechaFin = Convert.ToDateTime(fin.ToLower().Trim()).Date;
            //Ingresos entre las fechas (Agrupar por tipo de ingreso) y que no este en otro cierre
            var ingresos = await db.IngresosPendientesCierre
                                .Where(e => e.Estado == EstadoIngreso.Ejecutado && DbFunctions.TruncateTime(e.Created_at) >= fechaInicio && DbFunctions.TruncateTime(e.Created_at) <= fechaFin)
                                .OrderByDescending(e => e.TipoIngreso)
                                .ToListAsync();

            return Ok(ingresos.Select(e => new
            {
                e.Id,
                e.ClienteId,
                e.ClienteNombre,
                Created_at = e.Created_at.ToString("d"),
                Updated_at = e.Updated_at.ToString("d"),
                e.Descripcion,
                Estado = e.Estado.ToString(),
                TipoIngreso = e.TipoIngreso.ToString(),
                e.TramitadorId,
                e.TramitadorNombre,
                e.Valor,
                e.Producto,
                e.Referencia,
                TipoMovimiento = TipoMovimiento.Ingreso
            }));
        }

        public async Task<IHttpActionResult> Post(CierreDetalleViewModel model)
        {
            if (ModelState.IsValid)
            {
                var currentDetalle = await db.CierreDetalle.Where(e => e.CierreId == model.CierreId).ToListAsync();
                int nro = (currentDetalle.Max(e => (int?)e.Id) ?? 0) + 1;

                foreach (var item in model.Detalle)
                {
                    int countMovimiento = await db.CierreDetalle
                        .Where(e => e.CierreId == model.CierreId &&
                                    e.TipoMovimiento == item.TipoMovimiento &&
                                    e.MovimientoId == item.MovimientoId).CountAsync();
                    if (countMovimiento == 0)
                    {
                        item.CierreId = model.CierreId;
                        item.Id = nro;
                        db.CierreDetalle.Add(item);

                        nro++;
                    }
                }

                await db.SaveChangesAsync();
                await AddLog("Edit", model.CierreId.ToString(), model);

                return Ok(model.CierreId);
            }

            return BadRequest(ModelState);
        }

        public async Task<IHttpActionResult> Delete(long c, int i)
        {
            var detalle = await db.CierreDetalle
                .Include(e => e.Cierre)
                .Where(e => e.CierreId == c && e.Id == i)
                .FirstOrDefaultAsync();

            if (detalle == null)
                return NotFound();

            if (detalle.Cierre.Estado != EstadoCierre.Pendiente)
                return BadRequest("Movimiento no puede ser eliminado (El cierre debe estar en estado pendiente");

            db.CierreDetalle.Remove(detalle);
            await db.SaveChangesAsync();

            await AddLog("Delete", c.ToString() + "-" + i.ToString(), detalle);
            return Ok("Movimiento eliminado con exito");
        }
    }
}
