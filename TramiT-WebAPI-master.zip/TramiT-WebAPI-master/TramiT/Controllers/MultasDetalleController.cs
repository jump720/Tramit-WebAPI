﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using TramiT.Models;

namespace TramiT.Controllers
{
    public class MultasDetalleController : ApiBaseController
    {
        private TramiTDBContext db = new TramiTDBContext();

        [HttpGet]
        [Route("api/MultasDetalle/GetByCliente/{cliente_id}")]
        public async Task<IHttpActionResult> GetByCliente(string cliente_id, int page = 0, int length = 10, string search = "")
        {
            var dataQuery = db.MultasDetalle
                            .Where(e => e.Multas.Clientes.Identificacion.ToLower() == cliente_id)
                            .AsQueryable();

            if (!string.IsNullOrWhiteSpace(search))
            {
                string value = search.ToLower().Trim();
                dataQuery = dataQuery.Where(e => e.Comparendo.ToString().Contains(value) ||
                            e.Resolucion.ToLower().ToString().Contains(value) ||
                            e.MultaId.ToString().Contains(value) ||
                            e.TipoComparendos.Nombre.ToLower().ToString().Contains(value) ||
                            e.Multas.Tramitadores.Nombre.ToLower().ToString().Contains(value) ||
                            e.Estado.ToString().ToLower().ToString().Contains(value));
            }

            int count = await dataQuery.CountAsync();

            var data = await dataQuery
                .Include(e => e.Multas)
                .Include(e => e.Multas.Tramitadores)
                .Include(e => e.Multas.Productos)
                .Include(e => e.TipoComparendos)
                .OrderByDescending(e => e.Created_at)
                .ThenBy(e => e.Multas.TramitadorId)
                .ThenBy(e => e.TipoComparendoId)
                .Skip(page * length).Take(length).ToListAsync();

            return Ok(new
            {
                count,
                data = data.Select(e => new
                {
                    Id = e.MultaId.ToString() + "-" + e.ItemId.ToString(),
                    e.MultaId,
                    e.ItemId,
                    TipoComparendoNombre = e.TipoComparendos.Nombre,
                    Created_at = e.Created_at.ToString("d"),
                    Updated_at = e.Updated_at.ToString("d"),
                    e.Comparendo,
                    e.Resolucion,
                    TramitadorNombre = e.Multas.Tramitadores.Nombre,
                    TramitadorComision = e.Multas.ComisionTramitador,
                    Estado = e.Estado.ToString(),
                    e.ValorComparendo,
                    e.Porcentaje,
                    e.Valor                    
                })
            });
        }


        [HttpGet]
        [Route("api/MultasDetalle/GetByTramitador/{tramitador_id}")]
        public async Task<IHttpActionResult> GetByTramitador(string tramitador_id, int page = 0, int length = 10, string search = "")
        {
            var dataQuery = db.MultasDetalle
                            .Where(e => e.Multas.Tramitadores.Codigo.ToLower() == tramitador_id)
                            .AsQueryable();

            if (!string.IsNullOrWhiteSpace(search))
            {
                string value = search.ToLower().Trim();
                dataQuery = dataQuery.Where(e => e.Comparendo.ToString().Contains(value) ||
                            e.Resolucion.ToLower().ToString().Contains(value) ||
                            e.MultaId.ToString().Contains(value) ||
                            e.TipoComparendos.Nombre.ToLower().ToString().Contains(value) ||
                            e.Multas.Tramitadores.Nombre.ToLower().ToString().Contains(value) ||
                            e.Estado.ToString().ToLower().ToString().Contains(value));
            }

            int count = await dataQuery.CountAsync();

            var data = await dataQuery
                .Include(e => e.Multas)
                .Include(e => e.Multas.Tramitadores)
                .Include(e => e.Multas.Productos)
                .Include(e => e.TipoComparendos)
                .OrderByDescending(e => e.Created_at)
                .ThenBy(e => e.Multas.TramitadorId)
                .ThenBy(e => e.TipoComparendoId)
                .Skip(page * length).Take(length).ToListAsync();

            return Ok(new
            {
                count,
                data = data.Select(e => new
                {
                    Id = e.MultaId.ToString() + "-" + e.ItemId.ToString(),
                    e.MultaId,
                    e.ItemId,
                    TipoComparendoNombre = e.TipoComparendos.Nombre,
                    Created_at = e.Created_at.ToString("d"),
                    Updated_at = e.Updated_at.ToString("d"),
                    e.Comparendo,
                    e.Resolucion,
                    TramitadorNombre = e.Multas.Tramitadores.Nombre,
                    TramitadorComision = e.Multas.ComisionTramitador,
                    Estado = e.Estado.ToString(),
                    e.ValorComparendo,
                    e.Porcentaje,
                    e.Valor
                })
            });
        }


    }
}
