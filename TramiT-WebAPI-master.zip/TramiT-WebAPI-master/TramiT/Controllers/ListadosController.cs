﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http;
using TramiT.Models;
using TramiT.Models.ViewModel;
namespace TramiT.Controllers
{
    public class ListadosController : ApiBaseController
    {
        private TramiTDBContext db = new TramiTDBContext();

        public async Task<IHttpActionResult> Get(int page = 0, int length = 20, string search = "")
        {
            var dataQuery = db.Listados.AsQueryable();

            if (!string.IsNullOrWhiteSpace(search))
            {
                string value = search.ToLower().Trim();
                dataQuery = dataQuery.Where(e => e.Id.ToString().Contains(value) || e.Titulo.ToLower().ToString().Contains(value));
            }

            int count = await dataQuery.CountAsync();

            var data = await dataQuery
                .Include(e => e.ListadosDetalle)
                .OrderBy(e => e.Estado)
                .ThenByDescending(e => e.Created_at)
                .ThenByDescending(e => e.Titulo)
                .Skip(page * length).Take(length).ToListAsync();

            return Ok(new
            {
                count,
                data = data.Select(e => new
                {
                    e.Id,
                    e.Titulo,
                    Estado = e.Estado.ToString(),
                    Created_at = e.Created_at.ToString("d"),
                    Updated_at = e.Updated_at.ToString("d"),
                    Comparendos = e.ListadosDetalle.Count()
                })
            });
        }
        
        public async Task<IHttpActionResult> Get(long id)
        {
            var listado = await db.Listados.Where(e => e.Id == id).FirstOrDefaultAsync();

            if (listado == null)
                return NotFound();

            var detalle = await db.ListadosDetalle.Where(e => e.ListadoId == id)
                            .OrderBy(e => e.Estado)
                            .ThenByDescending(e => e.MultasDetalle.MultaId)
                            .ThenByDescending(e => e.MultasDetalle.ItemId)
                            .Include(e => e.MultasDetalle)
                            .Include(e => e.MultasDetalle.Multas)
                            .Include(e => e.MultasDetalle.TipoComparendos)
                            .ToListAsync();

            return Ok(new
            {
                Listado = new
                {
                    listado.Id,
                    listado.Titulo,
                    Estado = listado.Estado.ToString(),
                    listado.Created_at,
                    listado.Updated_at
                },
                Detalle = detalle.Select(e => new
                {
                    e.ListadoId,
                    e.Id,
                    e.MultaId,
                    e.MultaItemId,
                    TipoComparendo = e.MultasDetalle.TipoComparendos.Nombre,
                    EstadoComparendo = e.MultasDetalle.Estado,
                    EstadoComparendoTexto = e.MultasDetalle.Estado.ToString(),
                    e.MultasDetalle.Comparendo,
                    e.MultasDetalle.Resolucion,
                    e.MultasDetalle.Multas.ClienteId,
                    e.MultasDetalle.ValorComparendo,
                    e.MultasDetalle.Porcentaje,
                    e.MultasDetalle.Valor,
                    e.Nota,
                    e.Estado,
                    EstadoTexto = e.Estado.ToString(),
                    Created_at = e.Created_at.ToString("d"),
                    Updated_at = e.Updated_at.ToString("d"),
                    e.Pagado
                })
            });
        }

        public async Task<IHttpActionResult> Post(ListadosViewModel model)
        {
            if (ModelState.IsValid)
            {
                db.Listados.Add(model.Listado);
                await db.SaveChangesAsync();

                await AddLog("Create", model.Listado.Id.ToString(), model);
                if (model.Detalle.Count > 0)
                {
                    await SaveDetalle(model.Listado.Id, model.Detalle);
                }

                return Ok(model.Listado.Id);
            }

            return BadRequest(ModelState);
        }

        public async Task<IHttpActionResult> Put(Listados model)
        {
            if (ModelState.IsValid)
            {
                db.Entry(model).State = EntityState.Modified;
                db.Entry(model).Property(e => e.Created_at).IsModified = false;
                db.Entry(model).Property(e => e.Estado).IsModified = false;
                await db.SaveChangesAsync();

                await AddLog("Edit", model.Id.ToString(), model);
                return Ok(model);
            }

            return BadRequest(ModelState);
        }

        [HttpGet]
        [Route("api/Listados/TituloDisponible")]
        public async Task<IHttpActionResult> TituloDisponible(string titulo)
        {
            var listado = await db.Listados.Where(e => e.Titulo.ToLower().Trim() == titulo.ToLower().Trim()).FirstOrDefaultAsync();

            return Ok(listado == null);
        }

        [HttpGet]
        [Route("api/Listados/GetMultas")]
        public async Task<IHttpActionResult> GetMultas(int TipoComparendo)
        {
            var multas = await db.MultasDetalle
                    .Include(e => e.Multas)
                    .Include(e => e.TipoComparendos)
                    .Include(e => e.ListadosDetalle)
                    .Where(e => e.TipoComparendoId == TipoComparendo &&
                                e.ListadosDetalle
                                    .Where(d => d.Estado != EstadoListadoDetalle.Eliminado)
                                    .ToList().Count == 0)
                    .Where(e => e.Estado != EstadoComparendo.Completado && e.Estado != EstadoComparendo.Anulado)
                    .Where(e => e.EnProcesoPago == false)
                    .OrderBy(e => e.Multas.ClienteId)
                    .ThenBy(e => e.MultaId)
                    .ThenBy(e => e.Estado)
                    .ToListAsync();

            return Ok(multas.Select(e => new
            {
                Id = e.MultaId.ToString() + "-" + e.ItemId.ToString(),
                e.MultaId,
                e.ItemId,
                e.Multas.ClienteId,
                e.TipoComparendoId,
                TipoComparendoNombre = e.TipoComparendos.Nombre,
                Estado = e.Estado.ToString(),
                e.Comparendo,
                e.Resolucion,
                e.ValorComparendo,
                e.Porcentaje,
                e.Valor,
                Fecha = e.Created_at.ToString("d"),
                Updated_at = e.Updated_at.ToString("d")
            }));
        }

        [HttpPost]
        [Route("api/Listados/SetPagado/{id}")]
        public async Task<IHttpActionResult> SetPagado(long id, bool pagado = true)
        {
            var multas = await db.ListadosDetalle
                        .Where(e => e.ListadoId == id && e.Pagado == false && e.Estado != EstadoListadoDetalle.Eliminado)
                        .ToListAsync();
            try
            {
                foreach (var m in multas)
                {
                    m.Pagado = pagado;
                    m.Updated_at = DateTime.Now;
                    db.ListadosDetalle.Attach(m);
                    db.Entry(m).Property("Pagado").IsModified = true;
                    db.Entry(m).Property("Updated_at").IsModified = true;

                    await db.SaveChangesAsync();
                }
            }
            catch (Exception)
            {
                return InternalServerError();
            }
            

            return Ok();
        }

        [HttpPost]
        [Route("api/Listados/Completar/{id}")]
        public async Task<IHttpActionResult> Completar(long id)
        {
            var listado = await db.Listados.Where(e => e.Id == id).FirstOrDefaultAsync();

            if (listado == null)
                return NotFound();
            if (listado.Estado == EstadoListado.Pendiente || listado.Estado == EstadoListado.Enviado)
            {
                listado.Estado = EstadoListado.Completado;
                db.Entry(listado).State = EntityState.Modified;
                db.Entry(listado).Property(e => e.Created_at).IsModified = false;
                await db.SaveChangesAsync();
                await AddLog("Completar", listado.Id.ToString(), listado);
                return Ok(listado.Id);
            }

            ModelState.AddModelError("", "Listado no puede ser completado");
            return BadRequest(ModelState);

        }

        [HttpPost]
        [Route("api/Listados/Anular/{id}")]
        public async Task<IHttpActionResult> Anular(long id)
        {
            var listado = await db.Listados.Where(e => e.Id == id).FirstOrDefaultAsync();

            if (listado == null)
                return NotFound();

            if (listado.Estado == EstadoListado.Pendiente || listado.Estado == EstadoListado.Enviado)
            {
                listado.Estado = EstadoListado.Anulado;
                db.Entry(listado).State = EntityState.Modified;
                db.Entry(listado).Property(e => e.Created_at).IsModified = false;
                await db.SaveChangesAsync();
                await AddLog("Anular", listado.Id.ToString(), listado);
                return Ok(listado.Id);
            }

            ModelState.AddModelError("", "Listado no puede ser anulado");
            return BadRequest(ModelState);
        }

        [HttpPost]
        [Route("api/Listados/Pendiente/{id}")]
        public async Task<IHttpActionResult> Pendiente(long id)
        {
            var listado = await db.Listados.Where(e => e.Id == id).FirstOrDefaultAsync();

            if (listado == null)
                return NotFound();

            if (listado.Estado == EstadoListado.Enviado)
            {
                listado.Estado = EstadoListado.Pendiente;
                db.Entry(listado).State = EntityState.Modified;
                db.Entry(listado).Property(e => e.Created_at).IsModified = false;
                await db.SaveChangesAsync();
                await AddLog("Pendiente", listado.Id.ToString(), listado);
                return Ok(listado.Id);
            }

            ModelState.AddModelError("", "Listado no puede ser puesto como pendiente");
            return BadRequest(ModelState);
        }

        [HttpPost]
        [Route("api/Listados/Enviar/{id}")]
        public async Task<IHttpActionResult> Enviar(long id)
        {
            var listado = await db.Listados.Where(e => e.Id == id).FirstOrDefaultAsync();

            if (listado == null)
                return NotFound();
            
            if (listado.Estado == EstadoListado.Pendiente)
            {
                listado.Estado = EstadoListado.Enviado;
                db.Entry(listado).State = EntityState.Modified;
                db.Entry(listado).Property(e => e.Created_at).IsModified = false;
                await db.SaveChangesAsync();
                await AddLog("Enviar", listado.Id.ToString(), listado);
                return Ok(listado.Id);
            }

            ModelState.AddModelError("", "Listado no puede ser enviado");
            return BadRequest(ModelState);

        }

        private async Task SaveDetalle(long l, List<ListadosDetalle> detalle)
        {
            int nro = 1;

            foreach (var item in detalle)
            {
                //Si tiene el Item en cero es nuevo registro
                if (item.Id == 0)
                {
                    item.ListadoId = l;
                    item.Id = nro;

                    db.ListadosDetalle.Add(item);
                    nro++;
                }

                await db.SaveChangesAsync();
            }
        }
    }
}
