﻿using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http;
using TramiT.Models;

namespace TramiT.Controllers
{
    public class ClientesController : ApiBaseController
    {
        private TramiTDBContext db = new TramiTDBContext();


        public async Task<IHttpActionResult> Get(int page = 0, int length = 20, string search = "")
        {
            var dataQuery = db.Clientes.AsQueryable();

            if (!string.IsNullOrWhiteSpace(search))
            {
                string value = search.ToLower().Trim();
                dataQuery = dataQuery
                        .Where(e => e.Identificacion.ToLower().ToString().Contains(value) ||
                        e.Nombres.ToLower().Contains(value) || e.Apellidos.ToLower().Contains(value)
                        || (e.Identificacion + " - " + e.Nombres + " " + e.Apellidos).ToLower().Contains(value));
            }

            int count = await dataQuery.CountAsync();

            var data = await dataQuery
                .OrderByDescending(e => e.Identificacion)
                .ThenBy(e => e.Nombres)
                .ThenBy(e => e.Apellidos)
                .Skip(page * length).Take(length).ToListAsync();

            return Ok(new
            {
                count,
                data = data.Select(e => new
                {
                    e.Identificacion,
                    e.Nombres,
                    e.Apellidos,
                    e.Celular,
                    e.Correo,
                    Fullname = e.Identificacion + " - " + e.Nombres + " " + e.Apellidos
                })
            });
        }

        public async Task<IHttpActionResult> Get(string id)
        {
            var cliente = await db.Clientes.Where(e => e.Identificacion == id).FirstOrDefaultAsync();

            if (cliente == null)
                return NotFound();

            return Ok(cliente);
        }

        public async Task<IHttpActionResult> Post(Clientes model)
        {

            if (!IsIdentificacionAvailable(model.Identificacion))
            {
                ModelState.AddModelError("Identificacion", "El # de identificación ya existe");
            }

            if (ModelState.IsValid)
            {
                db.Clientes.Add(model);
                await db.SaveChangesAsync();

                await AddLog("Create", model.Identificacion, model);
                return Ok(model);
            }

            return BadRequest(ModelState);
        }

        public async Task<IHttpActionResult> Put(Clientes model)
        {
            if (ModelState.IsValid)
            {
                db.Entry(model).State = EntityState.Modified;
                db.Entry(model).Property(e => e.Created_at).IsModified = false;
                await db.SaveChangesAsync();

                await AddLog("Edit", model.Identificacion, model);
                return Ok(model);
            }

            return BadRequest(ModelState);
        }

        public async Task<IHttpActionResult> Delete(string id)
        {
            Clientes cliente = await db.Clientes
                    .Include(e => e.Tramites)
                    .Where(e => e.Identificacion == id).FirstOrDefaultAsync();
            if (cliente == null)
                return NotFound();

            //Validar que no tenga tramites
            if (cliente.Tramites.Count == 0)
            {
                db.Clientes.Remove(cliente);
                await db.SaveChangesAsync();

                await AddLog("Delete", id, cliente);
                return Ok("Cliente eliminado con exito");
            }
            return BadRequest("Cliente no puede ser eliminado, tiene tramites registrados");
        }

        private bool IsIdentificacionAvailable(string identificacion)
        {
            return !db.Clientes.Any(e => e.Identificacion == identificacion);
        }

        //[HttpGet]
        //[Route("api/Clientes/GetData/{id}/")]
        //public async Task<IHttpActionResult> GetData(string id)
        //{
        //    var cliente = await db.Clientes.Where(e => e.Identificacion == id).FirstOrDefaultAsync();

        //    if (cliente == null)
        //        return NotFound();

        //    return Ok(cliente);
        //}
    }
}
