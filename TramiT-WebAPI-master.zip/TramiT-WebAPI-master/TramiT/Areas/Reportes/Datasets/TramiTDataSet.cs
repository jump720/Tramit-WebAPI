﻿namespace TramiT.Areas.Reportes.Datasets
{
}

namespace TramiT.Areas.Reportes.Datasets
{


    public partial class TramiTDataSet
    {
    }
}
namespace TramiT.Areas.Reportes.Datasets {
    
    
    public partial class TramiTDataSet {
    }
}
