﻿using Microsoft.Reporting.WebForms;
using System.Collections.Generic;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Mvc;
using TramiT.Areas.Reportes.Models;
using TramiT.Models;
//https://docs.microsoft.com/en-us/sql/reporting-services/application-integration/integrating-reporting-services-using-reportviewer-controls-get-started?view=sql-server-ver15
namespace TramiT.Areas.Reportes.Controllers
{

    public class ListadosController : Controller
    {
        private TramiTDBContext db = new TramiTDBContext();

        // GET: Reportes/Listados
        [Authorize]
        //[Route("Reportes/Listado/{id}")]
        public async Task<FileContentResult> Index(long id = 7, bool ImprimirValores = true)
        {
            LocalReport lr = new LocalReport();

            string path = Path.Combine(Server.MapPath("~/Areas/Reportes/Views"), $"Listados/DetalleListado.rdlc");
            if (System.IO.File.Exists(path))
                lr.ReportPath = path;

            var Listado = await db.Listados.Where(e => e.Id == id).ToListAsync();
            var Detalle = await db.ListadosDetalle
                    .Include(e => e.MultasDetalle)
                    .Include(e => e.MultasDetalle.Multas)
                    .OrderBy(e => e.MultasDetalle.Multas.ClienteId)
                    .Where(e => e.ListadoId == id).ToListAsync();
            var viewDetalle = Detalle
                .GroupBy(e => e.MultasDetalle.Multas.ClienteId).Select(e => new
                {
                    Cliente = e.Key,
                    Comparendos = e.Select(c => c.MultasDetalle.Comparendo),
                    Resoluciones = e.Select(c => c.MultasDetalle.Resolucion),
                    ValorComparendo = e.Select(c => c.MultasDetalle.ValorComparendo).Sum()
                }).ToList()
                .Select(l => new
                {
                    l.Cliente,
                    Comparendo = string.Join(" | ", l.Comparendos),
                    Resolucion = string.Join(" | ", l.Resoluciones),
                    l.ValorComparendo
                });

            var config = new List<ConfiguracionReporte>
            {
                new ConfiguracionReporte { ImprimirValores = ImprimirValores }
            };
            //e.ListadoId,
            //    e.Estado,
            //    e.Created_at,
            //    e.Updated_at,
            //    e.MultaId,
            //    e.MultaItemId,
            //    e.Pagado,
            //    e.Nota,
            //    Cliente = e.MultasDetalle.Multas.ClienteId,
            //    EstadoComparendo = e.MultasDetalle.Estado.ToString(),
            //    e.MultasDetalle.Comparendo,
            //    e.MultasDetalle.Resolucion,
            //    e.MultasDetalle.ValorComparendo,
            //    e.MultasDetalle.Porcentaje,
            //    e.MultasDetalle.Valor
            ReportDataSource ListadosDS = new ReportDataSource("Listados", Listado);
            ReportDataSource ListadosDetalleDS = new ReportDataSource("ListadosDetalle", viewDetalle);
            ReportDataSource ConfiguracionReporteDS = new ReportDataSource("Configuracion", config);

            lr.DataSources.Add(ListadosDS);
            lr.DataSources.Add(ListadosDetalleDS);
            lr.DataSources.Add(ConfiguracionReporteDS);

            return File(ReportByte(lr, "PDF"), "application/pdf");
        }


        private byte[] ReportByte(LocalReport lr, string tipo = "")
        {
            string reportType = tipo;
            string deviceInfo = "<DeviceInfo>" + "  <OutputFormat>" + tipo + "</OutputFormat>" + "</DeviceInfo>";
            byte[] renderedBytes;
            renderedBytes = lr.Render(
                reportType,
                deviceInfo,
                out string mimeType,
                out string encoding,
                out string fileNameExtension,
                out string[] streams,
                out Warning[] warnings);

            return renderedBytes;
        }
    }
}