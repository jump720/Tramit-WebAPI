﻿namespace TramiT.Areas.Reportes.Models
{
    public class ConfiguracionReporte
    {
        public bool ImprimirValores { get; set; }
    }
}