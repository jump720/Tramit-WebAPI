﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TramiT.Classes
{
    public static class Fn
    {
        public static string GetJsonString(object data)
        {
            string jsonString = null;

            if (data != null)
            {
                jsonString = new System.Web.Script.Serialization.JavaScriptSerializer().Serialize(data);
                jsonString = Newtonsoft.Json.Linq.JObject.Parse(jsonString).ToString(Newtonsoft.Json.Formatting.Indented);
            }

            return jsonString;
        }

        public class EnumData
        {
            public int Value { get; set; }
            public string Name { get; set; }
        }

        public static IEnumerable<EnumData> EnumToIEnumarable<T>()
        {
            if (typeof(T).BaseType != typeof(Enum))
                throw new InvalidCastException();

            var enumValues = (T[])Enum.GetValues(typeof(T));
            var enumList = from value in enumValues
                           select new EnumData { Value = Convert.ToInt32(value), Name = value.ToString().Replace("__", "-").Replace("_", " ") };

            return enumList;
        }

    }
}