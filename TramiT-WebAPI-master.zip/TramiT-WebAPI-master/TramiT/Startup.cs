﻿using System;
using System.Globalization;
using System.Threading.Tasks;
using Microsoft.Owin;
using Owin;

[assembly: OwinStartup(typeof(TramiT.Startup))]

namespace TramiT
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            //var cultureInfo = new CultureInfo("en-CO");
            //CultureInfo.DefaultThreadCurrentCulture = cultureInfo;
            //CultureInfo.DefaultThreadCurrentUICulture = cultureInfo;

            // Para obtener más información sobre cómo configurar la aplicación, visite https://go.microsoft.com/fwlink/?LinkID=316888
            app.UseCors(Microsoft.Owin.Cors.CorsOptions.AllowAll);
            ConfigureAuth(app);

            
        }

        
    }
}
