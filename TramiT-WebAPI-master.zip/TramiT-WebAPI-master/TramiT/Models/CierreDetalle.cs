﻿

namespace TramiT.Models
{
    using Newtonsoft.Json;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Globalization;
    using System.Web.Script.Serialization;

    [Table("CierreDetalle")]
    public partial class CierreDetalle
    {
        public CierreDetalle()
        {
            Created_at = DateTime.Now;
            Updated_at = DateTime.Now;
        }

        [Key]
        [Column(Order = 0)]
        public long CierreId { get; set; }

        [Key]
        [Column(Order = 1)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Id { get; set; }

        [Required]
        [Display(Name = "Tipo movimiento")]
        public TipoMovimiento TipoMovimiento { get; set; }

        [Required]
        [StringLength(10)]
        [Display(Name = "Movimiento")]
        public string MovimientoId { get; set; }

        [DataType(DataType.Date)]
        [Display(Name = "Fecha creación")]
        public DateTime Created_at { get; set; }

        [DataType(DataType.Date)]
        [Display(Name = "Fecha actualización")]
        public DateTime Updated_at { get; set; }

        [Display(Name = "Creado por")]
        public string Created_by { get; set; }

        [Display(Name = "Actualizado por")]
        public string Updated_by { get; set; }

        [JsonIgnore, ScriptIgnore]
        public virtual Cierre Cierre { get; set; }
    }


    public enum TipoMovimiento
    {
        Gasto = 1,
        Ingreso = 2
    }
}