﻿namespace TramiT.Models
{
    using Newtonsoft.Json;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Web.Script.Serialization;

    [Table("Listados")]
    public partial class Listados
    {
        public Listados()
        {
            Created_at = DateTime.Now;
            Updated_at = DateTime.Now;
            Estado = EstadoListado.Pendiente;
        }

        [Key]
        [Display(Name = "ID")]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }

        [Required]
        [StringLength(100)]
        [Display(Name = "Titulo")]
        public string Titulo { get; set; }

        [Display(Name = "Fecha creación")]
        public DateTime Created_at { get; set; }

        [Display(Name = "Fecha actualización")]
        public DateTime Updated_at { get; set; }

        [Display(Name = "Estado")]
        public EstadoListado Estado { get; set; }

        [JsonIgnore, ScriptIgnore]
        public virtual ICollection<ListadosDetalle> ListadosDetalle { get; set; }
    }


    public enum EstadoListado
    {
        Pendiente = 1,
        Enviado = 2,
        Completado = 3,
        Anulado = 4
    }
}