﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace TramiT.Models.ViewModel
{
    public class ListadosDetalleViewModel
    {
        [Required]
        public int ListadoId { get; set; }
        public List<ListadosDetalle> Detalle { get; set; }
    }

    public class ListadosDetalleEditViewModel
    {
        [Required]
        public long ListadoId { get; set; }

        [Required]
        public int Id { get; set; }      

        [StringLength(500)]
        public string Nota { get; set; }

        [Required]
        public EstadoListadoDetalle Estado { get; set; }

        [Required]
        public long MultaId { get; set; }

        [Required]
        public int MultaItemId { get; set; }

        [Required]
        [Display(Name = "Estado")]
        public EstadoComparendo EstadoComparendo { get; set; }

        public bool Pagado { get; set; }
    }
}