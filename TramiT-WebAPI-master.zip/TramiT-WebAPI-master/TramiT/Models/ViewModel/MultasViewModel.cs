﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TramiT.Models.ViewModel
{
    public class MultasViewModel
    {
        public Multas Multa { get; set; }
        public List<MultasDetalle> Detalle { get; set; }
    }
}