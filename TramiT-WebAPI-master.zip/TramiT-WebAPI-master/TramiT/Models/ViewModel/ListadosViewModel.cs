﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TramiT.Models.ViewModel
{
    public class ListadosViewModel
    {
        public Listados Listado { get; set; }
        public List<ListadosDetalle> Detalle { get; set; }
    }
}