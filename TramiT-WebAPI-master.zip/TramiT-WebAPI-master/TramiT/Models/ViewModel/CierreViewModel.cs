﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TramiT.Models.ViewModel
{
    public class CierreViewModel
    {
        public Cierre Cierre { get; set; }
        public List<CierreDetalle> Detalle { get; set; }
    }

}