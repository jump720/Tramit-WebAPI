﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace TramiT.Models.ViewModel
{
    public class CierreDetalleViewModel
    {
        [Required]
        public int CierreId { get; set; }
        public List<CierreDetalle> Detalle { get; set; }
    }
}