﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TramiT.Models.ViewSql
{
    [Table("VW_GastosPendientesCierre")]
    public class GastosPendientesCierre
    {
        public long Id { get; set; }
        
        [Display(Name = "Descripción")]
        public string Descripcion { get; set; }
        
        [Display(Name = "Referencia")]
        public string Referencia { get; set; }
        
        [Display(Name = "Tipo")]
        public TipoGasto TipoGasto { get; set; }

        [Display(Name = "Estado")]
        public EstadoGasto Estado { get; set; }

        [Display(Name = "Nota")]
        public string Nota { get; set; }

        [Display(Name = "Valor")]
        public double Valor { get; set; }

        [Display(Name = "Fecha creación")]
        public DateTime Created_at { get; set; }

        [Display(Name = "Fecha actualización")]
        public DateTime Updated_at { get; set; }

        [Display(Name = "Creado por")]
        public string Created_by { get; set; }

        [Display(Name = "Actualizado por")]
        public string Updated_by { get; set; }

        public string ClienteId { get; set; }
        public string ClienteNombre { get; set; }
        public string TramitadorId { get; set; }
        public string TramitadorNombre { get; set; }
        public string EstadoMovimiento { get; set; }
        public string Producto { get; set; }
    }
}