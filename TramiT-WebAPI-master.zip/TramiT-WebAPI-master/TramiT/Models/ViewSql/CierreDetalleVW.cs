﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace TramiT.Models.ViewSql
{
    [Table("VW_CierreDetalle")]
    public class CierreDetalleVW
    {
        #region CierreDetalle
        public long CierreId { get; set; }

        public int Id { get; set; }

        [Display(Name = "Tipo movimiento")]
        public TipoMovimiento TipoMovimiento { get; set; }

        [Display(Name = "Movimiento")]
        public string MovimientoId { get; set; }

        [Display(Name = "Fecha creación")]
        public DateTime Created_at { get; set; }

        [Display(Name = "Fecha actualización")]
        public DateTime Updated_at { get; set; }

        [Display(Name = "Creado por")]
        public string Created_by { get; set; }

        [Display(Name = "Actualizado por")]
        public string Updated_by { get; set; }
        #endregion

        #region Movimiento(Gasto o Ingreso)
        public string MovimientoDesc { get; set; }
        public double MovimientoValor { get; set; }
        public DateTime MovimientoCreated_at { get; set; }
        public EstadoGasto MovimientoEstado { get; set; } //Revisar como unificar el estado de los gastos e ingresos
        public TipoGasto MovimientoTipo { get; set; }//Revisar como unificar el tipo de los gastos e ingresos
        public string Referencia { get; set; }
        #endregion

        #region Información Adicional
        public string ClienteId { get; set; }
        public string ClienteNombre { get; set; }
        public string TramitadorId { get; set; }
        public string TramitadorNombre { get; set; }
        public string EstadoMovimiento { get; set; }
        public string Producto { get; set; }
        #endregion
    }
}