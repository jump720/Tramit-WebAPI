﻿namespace TramiT.Models
{
    using Newtonsoft.Json;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Globalization;
    using System.Web.Script.Serialization;

    [Table("Multas")]
    public partial class Multas
    {

        public Multas()
        {
            Created_at = DateTime.Now;
            Updated_at = DateTime.Now;
            Clasificacion = Clasificacion.Normal;
        }

        [Key]
        [Display(Name = "ID")]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }

        [Required]
        [StringLength(20)]
        [Display(Name = "Cliente")]
        public string ClienteId { get; set; }

        [Required]
        [Display(Name = "Producto")]
        public int ProductoId { get; set; }

        [Required]
        [StringLength(20)]
        [Display(Name = "Tramidador")]
        public string TramitadorId { get; set; }

        [Display(Name = "Comisión Tramitador")]
        public double? ComisionTramitador { get; set; }

        [Required]
        [Display(Name = "Clasificación")]
        public Clasificacion Clasificacion { get; set; }

        [DataType(DataType.Date)]
        [Display(Name = "Fecha creación")]
        public DateTime Created_at { get; set; }

        [Display(Name = "Fecha actualización")]
        public DateTime Updated_at { get; set; }

        [StringLength(500)]
        [Display(Name = "Nota")]
        public string Nota { get; set; }

        [JsonIgnore, ScriptIgnore]
        public virtual Clientes Clientes { get; set; }
        [JsonIgnore, ScriptIgnore]
        public virtual Tramitadores Tramitadores { get; set; }
        [JsonIgnore, ScriptIgnore]
        public virtual Productos Productos { get; set; }

        [JsonIgnore, ScriptIgnore]
        public virtual ICollection<MultasDetalle> MultasDetalle { get; set; }
    }

    public enum Clasificacion
    {
        Normal = 1,
        Coactivo = 2,
        Incumplido = 3,
        Fallo = 4,
        Mixto = 5
    }
}