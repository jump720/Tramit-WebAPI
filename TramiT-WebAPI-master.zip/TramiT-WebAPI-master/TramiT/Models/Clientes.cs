﻿namespace TramiT.Models
{
    using Newtonsoft.Json;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Web.Mvc;
    using System.Web.Script.Serialization;

    [Table("Clientes")]
    public partial class Clientes
    {
        public Clientes()
        {
            Created_at = DateTime.Now;
            Updated_at = DateTime.Now;
        }

        [Key]
        [Required]
        [StringLength(20)]
        [Display(Name = "Identificación")]
        public string Identificacion { get; set; }

        [Required]
        [StringLength(50)]
        [Display(Name = "Nombres")]
        public string Nombres { get; set; }

        [Required]
        [StringLength(50)]
        [Display(Name = "Apellidos")]
        public string Apellidos { get; set; }

        [StringLength(30)]
        [Display(Name = "Celular")]
        public string Celular { get; set; }

        [StringLength(200)]
        [Display(Name = "Correo")]
        public string Correo { get; set; }

        [Display(Name = "Fecha creación")]
        public DateTime Created_at { get; set; }

        [Display(Name = "Fecha actualización")]
        public DateTime Updated_at { get; set; }

        [JsonIgnore, ScriptIgnore]
        public virtual ICollection<Tramites> Tramites { get; set; }
        [JsonIgnore, ScriptIgnore]
        public virtual ICollection<Multas> Multas { get; set; }

    }
}