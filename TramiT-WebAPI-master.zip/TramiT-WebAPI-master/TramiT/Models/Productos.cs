﻿

namespace TramiT.Models
{
    using Newtonsoft.Json;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Web.Script.Serialization;

    [Table("Productos")]
    public partial class Productos
    {
        public Productos()
        {
            Activo = true;
            TipoProducto = TipoProducto.Tramite;
        }

        [Key]
        [Display(Name = "ID")]
        public int Id { get; set; }

        [Required]
        [StringLength(50)]
        [Display(Name = "Nombre")]
        public string Nombre { get; set; }

        [Required]
        [Display(Name = "Tipo producto")]
        public TipoProducto TipoProducto { get; set; }

        [Required]
        [Display(Name = "Tipo Valor")]
        public TipoValor TipoValor { get; set; }

        [Required]
        [Display(Name = "Valor")]
        public double Valor { get; set; }

        [Display(Name = "Costo")]
        public double? Costo { get; set; }

        [Display(Name = "Activo")]
        public bool Activo { get; set; }

        [JsonIgnore, ScriptIgnore]
        public virtual ICollection<Tramites> Tramites { get; set; }
        [JsonIgnore, ScriptIgnore]
        public virtual ICollection<Multas> Multas { get; set; }

    }

    public enum TipoValor
    {
        Valor = 1,
        Porcentaje = 2
    }

    public enum TipoProducto
    {
        Tramite = 1,
        Multa = 2
    }
}