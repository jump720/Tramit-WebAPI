﻿
namespace TramiT.Models
{
    using Newtonsoft.Json;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Web.Script.Serialization;

    [Table("Cierre")]
    public partial class Cierre : IValidatableObject
    {
        public Cierre()
        {
            Created_at = DateTime.Now;
            Updated_at = DateTime.Now;
            Estado = EstadoCierre.Pendiente;
        }

        [Key]
        [Display(Name = "ID")]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }

        public string Titulo
        {
            get
            {
                return "Cierre - (" + FechaInicio.ToString("d") + " - " + FechaFin.ToString("d") + ")";
            }
        }

        [StringLength(500)]
        [Display(Name = "Nota")]
        public string Nota { get; set; }

        [DataType(DataType.Date)]
        [Display(Name = "Fecha inicio")]
        public DateTime FechaInicio { get; set; }

        [DataType(DataType.Date)]
        [Display(Name = "Fecha fin")]
        public DateTime FechaFin { get; set; }

        [Display(Name = "Estado")]
        public EstadoCierre Estado { get; set; }

        [DataType(DataType.Date)]
        [Display(Name = "Fecha creación")]
        public DateTime Created_at { get; set; }

        [DataType(DataType.Date)]
        [Display(Name = "Fecha actualización")]
        public DateTime Updated_at { get; set; }

        [Display(Name = "Creado por")]
        public string Created_by { get; set; }

        [Display(Name = "Actualizado por")]
        public string Updated_by { get; set; }

        [JsonIgnore, ScriptIgnore]
        public virtual ICollection<CierreDetalle> CierreDetalle { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if (Convert.ToDateTime(FechaInicio) > Convert.ToDateTime(FechaFin))
            {
                yield return new ValidationResult(
                    "La fecha inicial no puede ser mayor a la fecha final",
                    new[] { nameof(FechaInicio), nameof(FechaFin) });
            }
        }

    }

    public enum EstadoCierre
    {
        Pendiente = 1,
        Completado = 2,
        Anulado = 3
    }
}