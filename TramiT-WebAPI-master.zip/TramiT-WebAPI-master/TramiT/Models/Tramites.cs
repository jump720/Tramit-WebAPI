﻿

namespace TramiT.Models
{
    using Newtonsoft.Json;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Web.Script.Serialization;

    [Table("Tramites")]
    public partial class Tramites
    {
        public Tramites()
        {
            Created_at = DateTime.Now;
            Updated_at = DateTime.Now;
            Estado = EstadoTramite.Pendiente;
        }

        [Key]
        [Display(Name = "ID")]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }

        [Required]
        [StringLength(20)]
        [Display(Name = "Cliente")]
        public string ClienteId { get; set; }

        [Required]
        [Display(Name = "Estado")]
        public EstadoTramite Estado { get; set; }

        [Required]
        [Display(Name = "Producto")]
        public int ProductoId { get; set; }

        [StringLength(20)]
        [Display(Name = "# Comparendo")]
        public string Comparendo { get; set; }

        [StringLength(10)]
        [Display(Name = "Placa")]
        public string Placa { get; set; }

        [Required]
        [StringLength(20)]
        [Display(Name = "Tramidador")]
        public string TramitadorId { get; set; }

        [Display(Name = "Comisión Tramitador")]
        public double? ComisionTramitador { get; set; }

        [StringLength(500)]
        [Display(Name = "Nota")]
        public string Nota { get; set; }

        [Required]
        [Display(Name = "Valor Comparendo")]
        public double ValorComparendo { get; set; }

        [Display(Name = "Fecha creación")]
        public DateTime Created_at { get; set; }

        [Display(Name = "Fecha actualización")]
        public DateTime Updated_at { get; set; }

        [Display(Name = "Creado por")]
        public string Created_by { get; set; }

        [Display(Name = "Actualizado por")]
        public string Updated_by { get; set; }

        [JsonIgnore, ScriptIgnore]
        public virtual Clientes Clientes { get; set; }
        [JsonIgnore, ScriptIgnore]
        public virtual Tramitadores Tramitadores { get; set; }
        [JsonIgnore, ScriptIgnore]
        public virtual Productos Productos { get; set; }

        [JsonIgnore, ScriptIgnore]
        public virtual ICollection<TramitesDetalle> TramitesDetalle { get; set; }
    }

    public enum EstadoTramite
    {
        Pendiente = 1,
        Completado = 2,
        Anulado = 3,
    }

    //public enum TipoComparendo
    //{
    //    Normal = 1,
    //    Coactiva = 2
    //}


}