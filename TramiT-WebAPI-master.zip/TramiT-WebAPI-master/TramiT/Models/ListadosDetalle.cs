﻿namespace TramiT.Models
{
    using Newtonsoft.Json;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Web.Script.Serialization;

    [Table("ListadosDetalle")]
    public partial class ListadosDetalle
    {
        public ListadosDetalle()
        {
            Created_at = DateTime.Now;
            Updated_at = DateTime.Now;
            Estado = EstadoListadoDetalle.Pendiente;
            Pagado = false;
        }

        [Key]
        [Column(Order = 0)]
        public long ListadoId { get; set; }

        [Key]
        [Column(Order = 1)]
        public int Id { get; set; }

        [Required]
        [Display(Name = "Multa Id")]
        public long MultaId { get; set; }

        [Required]
        [Display(Name = "Comparendo")]
        public int MultaItemId { get; set; }

        [StringLength(500)]
        [Display(Name = "Nota")]
        public string Nota { get; set; }

        [Display(Name = "Fecha creación")]
        public DateTime Created_at { get; set; }

        [Display(Name = "Fecha actualización")]
        public DateTime Updated_at { get; set; }

        [Required]
        [Display(Name = "Estado")]
        public EstadoListadoDetalle Estado { get; set; }

        [Display(Name = "¿Pagado?")]
        public bool Pagado { get; set; }

        [Display(Name = "Creado por")]
        public string Created_by { get; set; }

        [Display(Name = "Actualizado por")]
        public string Updated_by { get; set; }

        [JsonIgnore, ScriptIgnore]
        public virtual MultasDetalle MultasDetalle { get; set; }

        [JsonIgnore, ScriptIgnore]
        public virtual Listados Listados { get; set; }
       
    }

    public enum EstadoListadoDetalle
    {
        Pendiente = 1,
        Aprobado = 2,
        No_Aprobado = 3,
        Eliminado = 4
    }
}