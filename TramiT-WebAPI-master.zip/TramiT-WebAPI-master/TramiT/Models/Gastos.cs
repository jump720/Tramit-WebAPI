﻿namespace TramiT.Models
{
    using Newtonsoft.Json;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Web.Script.Serialization;

    [Table("Gastos")]
    public partial class Gastos
    {
        public Gastos()
        {
            Created_at = DateTime.Now;
            Updated_at = DateTime.Now;
            TipoGasto = TipoGasto.Generico;
        }

        [Key]
        [Display(Name = "ID")]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }

        [Required]
        [StringLength(100)]
        [Display(Name = "Descripción")]
        public string Descripcion { get; set; }

        [StringLength(20)]
        [Display(Name = "Referencia")]
        public string Referencia { get; set; }
        
        [Required]
        [Display(Name = "Tipo")]
        public TipoGasto TipoGasto { get; set; }

        [Required]
        [Display(Name = "Estado")]
        public EstadoGasto Estado { get; set; }

        [StringLength(500)]
        [Display(Name = "Nota")]
        public string Nota { get; set; }

        [Required]
        [Display(Name = "Valor")]
        public double Valor { get; set; }

        [Display(Name = "Fecha creación")]
        public DateTime Created_at { get; set; }

        [Display(Name = "Fecha actualización")]
        public DateTime Updated_at { get; set; }

        [Display(Name = "Creado por")]
        public string Created_by { get; set; }

        [Display(Name = "Actualizado por")]
        public string Updated_by { get; set; }

    }

    public enum EstadoGasto
    {
        Pendiente = 1,
        Anulado = 2,
        Ejecutado = 3
    }

    public enum TipoGasto
    {
        Generico = 1,
        Tramite = 2,
        Multa = 3
    }

}