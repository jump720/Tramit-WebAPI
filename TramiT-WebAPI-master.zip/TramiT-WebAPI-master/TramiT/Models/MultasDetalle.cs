﻿namespace TramiT.Models
{
    using Newtonsoft.Json;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Web.Script.Serialization;

    [Table("MultasDetalle")]
    public partial class MultasDetalle
    {
        public MultasDetalle()
        {
            Created_at = DateTime.Now;
            Updated_at = DateTime.Now;
            Estado = EstadoComparendo.Se_adeuda;
        }

        [Key]
        [Column(Order = 0)]
        public long MultaId { get; set; }

        [Key]
        [Column(Order = 1)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int ItemId { get; set; }

        [Required]
        [Display(Name = "Tipo Comparendo")]
        public int TipoComparendoId { get; set; }

        [StringLength(20)]
        [Display(Name = "# Comparendo")]
        public string Comparendo { get; set; }

        [StringLength(20)]
        [Display(Name = "# Resolución")]
        public string Resolucion { get; set; }

        [Required]
        [Display(Name = "Valor comparendo")]
        public double ValorComparendo { get; set; }

        [Required]
        [Display(Name = "%")]
        public double Porcentaje { get; set; }

        [Required]
        [Display(Name = "Valor")]
        public double Valor { get; set; }

        [Required]
        [Display(Name = "Estado")]
        public EstadoComparendo Estado { get; set; }

        [Display(Name = "Fecha creación")]
        public DateTime Created_at { get; set; }

        [Display(Name = "Fecha actualización")]
        public DateTime Updated_at { get; set; }

        [Display(Name = "¿En proceso de pago?")]
        public bool EnProcesoPago { get; set; }

        [Display(Name = "Creado por")]
        public string Created_by { get; set; }

        [Display(Name = "Actualizado por")]
        public string Updated_by { get; set; }

        [JsonIgnore, ScriptIgnore]
        public virtual Multas Multas { get; set; }
        //[JsonIgnore, ScriptIgnore]
        public virtual TipoComparendos TipoComparendos { get; set; }

        [JsonIgnore, ScriptIgnore]
        public virtual ICollection<ListadosDetalle> ListadosDetalle { get; set; }
    }

    public enum EstadoComparendo
    {
        Se_adeuda = 1,//Editable
        Cobro_Coactivo = 2,//Editable
        Fallado = 3,//Editable
        Incumplido = 4,//Editable
        Devuelto = 5,//Editable
        Completado = 6,//No Editable
        Anulado = 7//No Editable
    }

    //estado de enviado al abogado y la fecha de envio
    
}