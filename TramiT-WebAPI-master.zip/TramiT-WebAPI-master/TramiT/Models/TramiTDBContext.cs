﻿
namespace TramiT.Models
{
    using Microsoft.AspNet.Identity.EntityFramework;
    using System.Data.Entity;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;
    using System.Web;
    using TramiT.Models.ViewSql;

    public partial class TramiTDBContext : IdentityDbContext<IdentityModel>
    {

        public TramiTDBContext() : base("name=TramiTDBContext", throwIfV1Schema: false)
        {
            Configuration.ProxyCreationEnabled = false;
            Configuration.LazyLoadingEnabled = false;
        }


        public static TramiTDBContext Create()
        {
            return new TramiTDBContext();
        }

        public virtual DbSet<Clientes> Clientes { get; set; }
        public virtual DbSet<Tramitadores> Tramitadores { get; set; }
        public virtual DbSet<Productos> Productos { get; set; }
        public virtual DbSet<Logs> Logs { get; set; }
        public virtual DbSet<Tramites> Tramites { get; set; }
        public virtual DbSet<TramitesDetalle> TramitesDetalle { get; set; }
        public virtual DbSet<Gastos> Gastos { get; set; }
        public virtual DbSet<TipoComparendos> TipoComparendos { get; set; }
        public virtual DbSet<Multas> Multas { get; set; }
        public virtual DbSet<MultasDetalle> MultasDetalle { get; set; }
        public virtual DbSet<Ingresos> Ingresos { get; set; }
        public virtual DbSet<Listados> Listados { get; set; }
        public virtual DbSet<ListadosDetalle> ListadosDetalle { get; set; }
        public virtual DbSet<Cierre> Cierre { get; set; }
        public virtual DbSet<CierreDetalle> CierreDetalle { get; set; }

        #region ViewSQL
        public virtual DbSet<GastosPendientesCierre> GastosPendientesCierre { get; set; }
        public virtual DbSet<IngresosPendientesCierre> IngresosPendientesCierre { get; set; }
        public virtual DbSet<CierreDetalleVW> CierreDetalleVW { get; set; }
        
        #endregion

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            //modelBuilder.Entity<IdentityRole>().HasData(new IdentityRole { Name = "Admin", NormalizedName = "Admin".ToUpper() });

            modelBuilder.Entity<Clientes>()
                .HasMany(e => e.Tramites)
                .WithRequired(e => e.Clientes)
                .HasForeignKey(e => e.ClienteId)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Clientes>()
                .HasMany(e => e.Multas)
                .WithRequired(e => e.Clientes)
                .HasForeignKey(e => e.ClienteId)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Tramitadores>()
               .HasMany(e => e.Tramites)
               .WithRequired(e => e.Tramitadores)
               .HasForeignKey(e => e.TramitadorId)
               .WillCascadeOnDelete(false);

            modelBuilder.Entity<Tramitadores>()
                .HasMany(e => e.Multas)
                .WithRequired(e => e.Tramitadores)
                .HasForeignKey(e => e.TramitadorId)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Productos>()
                .HasMany(e => e.Tramites)
                .WithRequired(e => e.Productos)
                .HasForeignKey(e => e.ProductoId)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Productos>()
                .HasMany(e => e.Multas)
                .WithRequired(e => e.Productos)
                .HasForeignKey(e => e.ProductoId)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Tramites>()
                .HasMany(e => e.TramitesDetalle)
                .WithRequired(e => e.Tramites)
                .HasForeignKey(e => e.TramiteId)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Multas>()
                .HasMany(e => e.MultasDetalle)
                .WithRequired(e => e.Multas)
                .HasForeignKey(e => e.MultaId)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<TipoComparendos>()
                 .HasMany(e => e.MultasDetalle)
                 .WithRequired(e => e.TipoComparendos)
                 .HasForeignKey(e => e.TipoComparendoId)
                 .WillCascadeOnDelete(false);

            modelBuilder.Entity<Listados>()
                .HasMany(e => e.ListadosDetalle)
                .WithRequired(e => e.Listados)
                .HasForeignKey(e => e.ListadoId)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<ListadosDetalle>()
              .HasIndex(e => new { e.ListadoId, e.MultaId, e.MultaItemId })
              .IsUnique(true);

            modelBuilder.Entity<MultasDetalle>()
                .HasMany(e => e.ListadosDetalle)
                .WithRequired(e => e.MultasDetalle)
                .HasForeignKey(e => new { e.MultaId, e.MultaItemId })
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Cierre>()
             .HasMany(e => e.CierreDetalle)
             .WithRequired(e => e.Cierre)
             .HasForeignKey(e => e.CierreId)
             .WillCascadeOnDelete(false);
        }

        //public override Task<int> SaveChangesAsync()
        //{
        //    var AddedEntities = ChangeTracker.Entries()
        //        .Where(E => E.State == EntityState.Added)
        //        .ToList();

        //    return base.SaveChangesAsync();
        //}

        public override Task<int> SaveChangesAsync(CancellationToken cancellationToken)
        {
            var AddedEntities = ChangeTracker.Entries()
               .Where(E => E.State == EntityState.Added || E.State == EntityState.Modified)
               .ToList();


            AddedEntities.ForEach(E =>
            {
                bool setCreadtedCUser = false, SetUpdatedUser = false;

                foreach (var p in E.CurrentValues.PropertyNames)
                {
                    if (p == "Created_by") setCreadtedCUser = true;
                    if (p == "Updated_by") SetUpdatedUser = true;
                }

                if (setCreadtedCUser && E.State == EntityState.Added)
                    E.Property("Created_by").CurrentValue = HttpContext.Current.User?.Identity?.Name;
                
                if (SetUpdatedUser)
                    E.Property("Updated_by").CurrentValue = HttpContext.Current.User?.Identity?.Name;

            });

            return base.SaveChangesAsync(cancellationToken);
        }

        //public override Task<int> SaveChangesAsync(bool acceptAllChangesOnSuccess, CancellationToken cancellationToken = default(CancellationToken))
        //{


        //    //var EditedEntities = ChangeTracker.Entries()
        //    //    .Where(E => E.State == EntityState.Modified)
        //    //    .ToList();

        //    //EditedEntities.ForEach(E =>
        //    //{
        //    //    E.Property("ModifiedDate").CurrentValue = DateTime.Now;
        //    //});

        //    return base.SaveChangesAsync(acceptAllChangesOnSuccess, cancellationToken);
        //}
    }


}