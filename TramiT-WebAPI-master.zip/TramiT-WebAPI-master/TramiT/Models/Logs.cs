﻿

namespace TramiT.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    [Table("Logs")]
    public partial class Logs
    {
        public Logs()
        {
            Created_at = DateTime.Now;
        }

        [Key]
        [Display(Name = "ID")]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }

        [Required]
        [Display(Name = "Fecha creación")]
        public DateTime Created_at { get; set; }

        [Required]
        [Display(Name = "Controlador")]
        [StringLength(50)]
        public string ControllerName { get; set; }

        [Required]
        [Display(Name = "Acción")]
        [StringLength(50)]
        public string ActionName { get; set; }

        [Required]
        [Display(Name = "LLave")]
        [StringLength(30)]
        public string KeyData { get; set; }

        [Required]
        [MaxLength]
        [Display(Name = "Data")]
        public string Data { get; set; }

        [Required]
        [StringLength(100)]
        [Display(Name = "Usuario")]
        public string User { get; set; }
    }
}