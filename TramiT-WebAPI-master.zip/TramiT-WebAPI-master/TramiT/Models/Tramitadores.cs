﻿

namespace TramiT.Models
{
    using Newtonsoft.Json;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Web.Script.Serialization;

    [Table("Tramitadores")]
    public partial class Tramitadores
    {
        public Tramitadores()
        {
            Created_at = DateTime.Now;
            Updated_at = DateTime.Now;
        }

        [Key]
        [Required]
        [StringLength(20)]
        [Display(Name = "Código")]
        public string Codigo { get; set; }

        [Required]
        [StringLength(100)]
        [Display(Name = "Nombre")]
        public string Nombre { get; set; }

        [Display(Name = "Porcentaje")]
        public double? Porcentaje { get; set;  }

        [Display(Name = "Fecha creación")]
        public DateTime Created_at { get; set; }

        [Display(Name = "Fecha actualización")]
        public DateTime Updated_at { get; set; }

        [JsonIgnore, ScriptIgnore]
        public virtual ICollection<Tramites> Tramites { get; set; }
        [JsonIgnore, ScriptIgnore]
        public virtual ICollection<Multas> Multas { get; set; }

    }
}