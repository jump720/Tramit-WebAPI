﻿namespace TramiT.Models
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    [Table("TramitesDetalle")]
    public partial class TramitesDetalle
    {
        [Key]
        [Column(Order = 0)]
        public long TramiteId { get; set; }

        [Key]
        [Column(Order = 1)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int ItemId { get; set; }

        [Required]
        [StringLength(50)]
        [Display(Name = "Concepto")]
        public string Concepto { get; set; }

        [Required]
        [Display(Name = "%")]
        public double Porcentaje { get; set; }

        [Required]
        [Display(Name = "Valor")]
        public double Valor { get; set; }

        public virtual Tramites Tramites { get; set; }
    }
}